package edu.neu.E.DataGenerate;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import edu.neu.E.DataGenerate.GenerateData;
import edu.neu.E.Evaluation.ETool;

import edu.neu.d1.communication.CommunicationInterface;
import edu.neu.d1.frames.Node;
import edu.neu.d2.communication.CommunicationNetworkNode;

/**
 * 
 * @author hermida
 *
 */
public class NetworkActionPanel extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private EInterface eInterface;
	private JButton createNetworkButton;
	//private JButton deactivateButton;
	//private JButton activateButton;
	//private JButton linkDownButton;
	//private JButton linkUpButton;
	//private JComboBox deactivateComboBox;
	//private JComboBox activateComboBox;
	private JComboBox nodeOneComboBox;
	private JComboBox nodeTwoComboBox;
	//private DefaultComboBoxModel deactivateComboBoxModel;
	//private DefaultComboBoxModel activateComboBoxModel;
	private DefaultComboBoxModel nodeOneComboBoxModel;
	private DefaultComboBoxModel nodeTwoComboBoxModel;
	//private String[] deactivateList;
	//private String[] activateList;
	private String[] nodeOneList;
	private String[] nodeTwoList;
	
	/**
	 * Construct the Network Action Panel
	 * @param eInterface
	 */
	public NetworkActionPanel(final EInterface eInterface) {
		// initialize all the instance variables
		this.eInterface = eInterface;
		//deactivateList = new String[]{};
		//deactivateComboBoxModel = new DefaultComboBoxModel(deactivateList);
		//deactivateComboBox = new JComboBox(deactivateComboBoxModel);
		//activateList = new String[]{};
		//activateComboBoxModel = new DefaultComboBoxModel(activateList);
		//activateComboBox = new JComboBox(activateComboBoxModel);
		nodeOneList = new String[]{"D1","D2"};
		nodeOneComboBoxModel = new DefaultComboBoxModel(nodeOneList);
		nodeOneComboBox = new JComboBox(nodeOneComboBoxModel);
		//nodeTwoList = new String[]{};
		//nodeTwoComboBoxModel = new DefaultComboBoxModel(nodeTwoList);
		//nodeTwoComboBox = new JComboBox(nodeTwoComboBoxModel);
		createNetworkButton = new JButton("Create Network");
		//deactivateButton = new JButton("Deactivate");
		//activateButton = new JButton("Activate");
		//linkDownButton = new JButton("Link Down");
		//linkUpButton = new JButton("Link Up");
		//linkUpButton.setEnabled(false); // disable it initially
		
		//setLayout(new GridLayout(1,9));
		// create the action for the createNetwork button
		createNetworkButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
//				if(nodeOneComboBox.getSelectedItem().equals("D1"))
//				{
//					EventQueue.invokeLater(new Runnable()
//					{
//						public void run() {
//							CommunicationInterface cnn = new CommunicationNetworkNode(GenerateData.uniqueNodeId++,eInterface);
//							((CommunicationNetworkNode)cnn).setVisible(true);
//							
//							
//							//For D2 Team test
//							CommunicationInterface cnn = new CommunicationNetworkNode(GenerateData.uniqueNodeId++,eInterface);
//							
//							GenerateData e = (GenerateData)eInterface;
//							//e.getEtool().setCnn(cnn);
//							// add the new communication network
//							e.add(GenerateData.uniqueNodeId-1, cnn);
//						}
//					});
//				}
					EventQueue.invokeLater(new Runnable()
					{
						public void run() {
							CommunicationInterface cnn = null;
							if(nodeOneComboBox.getSelectedItem().equals("D1"))
							{
								cnn = new edu.neu.d1.communication.CommunicationNetworkNode(GenerateData.uniqueNodeId++,eInterface);
								((edu.neu.d1.communication.CommunicationNetworkNode)cnn).setVisible(true);
							}
							else
							{//For D2 Team test
								cnn = new edu.neu.d2.communication.CommunicationNetworkNode(GenerateData.uniqueNodeId++,eInterface);
							}
							GenerateData e = (GenerateData)eInterface;
							//e.getEtool().setCnn(cnn);
							// add the new communication network
							e.add(GenerateData.uniqueNodeId-1, cnn);
						}
					});
			}
			
		});
		
		// add the create button to the panel
		add(createNetworkButton);
		
		add(nodeOneComboBox);
		//add(new JLabel(" To: "));
		//add(nodeTwoComboBox);
		
/*		linkDownButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				EvaluationTool eTool = (EvaluationTool)eInterface;

				synchronized(this) {
					eTool.getTopology().get(Integer.parseInt(nodeOneComboBox.getSelectedItem().toString())).remove(Integer.parseInt(nodeTwoComboBox.getSelectedItem().toString()));
					eTool.getTopology().get(Integer.parseInt(nodeTwoComboBox.getSelectedItem().toString())).remove(Integer.parseInt(nodeOneComboBox.getSelectedItem().toString()));
				}
				eTool.getNetwork().get(Integer.parseInt(nodeOneComboBox.getSelectedItem().toString())).setBackground(Color.RED);
				eTool.getNetwork().get(Integer.parseInt(nodeTwoComboBox.getSelectedItem().toString())).setBackground(Color.RED);
				
				linkDownButton.setEnabled(false);
				linkUpButton.setEnabled(true);
			}
		});
		
		add(linkDownButton);
		
		linkUpButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {

				EvaluationTool eTool = (EvaluationTool)eInterface;
				
				// change the network topology to reflect a link up
				synchronized(this) {
					eTool.getTopology().get(Integer.parseInt(nodeOneComboBox.getSelectedItem().toString())).put(Integer.parseInt(nodeTwoComboBox.getSelectedItem().toString()), new String("0"));
					eTool.getTopology().get(Integer.parseInt(nodeTwoComboBox.getSelectedItem().toString())).put(Integer.parseInt(nodeOneComboBox.getSelectedItem().toString()), new String("0"));
				}
				
				eTool.getNetwork().get(Integer.parseInt(nodeOneComboBox.getSelectedItem().toString())).setBackground(Color.GREEN);
				eTool.getNetwork().get(Integer.parseInt(nodeTwoComboBox.getSelectedItem().toString())).setBackground(Color.GREEN);
				
				linkDownButton.setEnabled(true);
				linkUpButton.setEnabled(false);
			}
		});
		
		add(linkUpButton);
		
		// add the deactivate combo box
		add(deactivateComboBox);

		
		// create the action for the deactivate button
		deactivateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(deactivateComboBox.getItemCount() > 0) {
					EvaluationTool e = (EvaluationTool)eInterface;
					// get the communication node to deactivate
					Integer node = Integer.parseInt((String)deactivateComboBox.getSelectedItem());
					
					// set the network node to RED (meaning deactivation).
					e.getCommunicationNetwork(node).setBackground(Color.RED);
	
					// remove the network node from the deactivate list.
					deactivateComboBox.removeItem(node.toString());
	
					// add the deactivated network node to the activate list.
					activateComboBox.addItem(node.toString());
					
					// deactivate the node
					e.deactivateNode(node);
				}
			}
		});
		
		// add the deactivate button to the panel
		add(deactivateButton);
		
		// add the activate button to the panel
		add(activateComboBox);

		// create the action for the activate button
		activateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if(activateComboBox.getItemCount() > 0) {
					EvaluationTool e = (EvaluationTool)eInterface;
					// get the communication node to deactivate
					Integer node = Integer.parseInt((String)activateComboBox.getSelectedItem());
					
					// set the network node to GREEN (meaning activation).
					e.getCommunicationNetwork(node).setBackground(Color.GREEN);
	
					// remove the network node from the activate list.
					activateComboBox.removeItem(node.toString());
	
					// add the activated network node to the deactivate list.
					deactivateComboBox.addItem(node.toString());
					
					// deactivate the node
					e.activateNode(node);
				}
			}
		});
		
		// add the activate button to the panel
		add(activateButton);
*/	
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Manage Networks");
		
		// set the border
		setBorder(titled);
		
	}

	
	/**
	 * Get the EInterface reference
	 * @return
	 */
	public EInterface geteInterface() {
		return eInterface;
	}

	/**
	 * set the EInterface
	 * @param eInterface
	 */
	public void seteInterface(EInterface eInterface) {
		this.eInterface = eInterface;
	}
	
	public JComboBox getNodeOneComboBox() {
		return nodeOneComboBox;
	}

	public JComboBox getNodeTwoComboBox() {
		return nodeTwoComboBox;
	}
}

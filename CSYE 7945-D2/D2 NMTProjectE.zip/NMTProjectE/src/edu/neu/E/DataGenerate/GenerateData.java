package edu.neu.E.DataGenerate;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JFrame;

import edu.neu.E.Evaluation.ConnectionStatus;
import edu.neu.E.Evaluation.ETool;
import edu.neu.E.Evaluation.NetworkOperation;
//import edu.neu.d1.communication.CommunicationNetworkNode;
import edu.neu.d1.communication.CommunicationInterface;
import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;
import edu.neu.d1.nmt.NMTNode;

/**
 * 
 * @author hermida
 *
 */
@SuppressWarnings("rawtypes")
public class GenerateData extends Node implements EInterface {

	private static final long serialVersionUID = 1L;
	public static int uniqueNodeId;
	
	private NetworkActionPanel networkActionPanel;
	private MessagePanel messagePanel;
	private DisplayTrafficPanel trafficPanel;
	private DisplayNetworksPanel networksPanel;
	private ETool etool;
	private NetworkOperation networkStatus;
	//private EOperation eoperation;
	private ConnectionStatus connectionstatus;
	
	// Keep a list of all the networks created
	private Hashtable<Integer, CommunicationInterface> network;
	
	// store the topology
	private HashMap<Integer, HashMap<Integer, String>> topology;
	
	/**
	 * Constructor
	 */
	public GenerateData() {
		super("GENERATE DATA");	
		etool= new ETool();
		// set the first node id to 1
		uniqueNodeId = 1;
		//this.etool = etool;
		// create the panels
		networkActionPanel = new NetworkActionPanel(this);
		messagePanel = new MessagePanel(this);
		trafficPanel = new DisplayTrafficPanel();
		networksPanel = new DisplayNetworksPanel();
		// initialize the Hash
		network = new Hashtable<Integer, CommunicationInterface>();
		topology = new HashMap<Integer, HashMap<Integer, String>>();
		
		// add the panels to the frame
		add(networkActionPanel, BorderLayout.NORTH);
		add(trafficPanel, BorderLayout.CENTER);
		add(networksPanel, BorderLayout.EAST);
		add(messagePanel, BorderLayout.SOUTH);
		
		// pack the frame
		pack();
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
				etool.setVisible(true);
				networkStatus = etool.getEpanel();
				//eoperation= etool.getEoperation();
				connectionstatus = etool.getConnectionStatus();
				
			}
		});
		// only the EvaluationTool can terminate the application
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

	}
	
	
	
	public ETool getEtool() {
		return etool;
	}



	public void setEtool(ETool etool) {
		this.etool = etool;
	}



	/**
	 * Get the NetworkActionPanel
	 */
	public NetworkActionPanel getNetworkActionPanel() {
		return networkActionPanel;
	}
	
	/**
	 * getter for the message panel
	 * @return DisplayPanel
	 */
	public MessagePanel getMessagePanel() {
		return messagePanel;
	}
	
	/**
	 * Getter for display networks panel
	 * @return
	 */
	public DisplayNetworksPanel getDisplayNetworksPanel() {
		return networksPanel;
	}
	
	/**
	 * Getter for display traffic panel
	 * @return
	 */
	public DisplayTrafficPanel getDisplayTrafficPanel() {
		return trafficPanel;
	}
	
	/**
	 * Return a CommunicationNetworkNode reference
	 * @param nodeId
	 * @return communicationNetworkNode, null otherwise
	 */
	public CommunicationInterface getCommunicationNetwork(int nodeId) {
		Integer id = new Integer(nodeId);
		if(network.containsKey(id)) {
			return network.get(id);
		} else {
			return null;
		}
	}
	
	public CommunicationInterface getCommunicationNetwork(Integer nodeId) {
		if(network.containsKey(nodeId)) {
			return network.get(nodeId);
		} else {
			return null;
		}
	}
	/**
	 * get the list of networks.
	 * @return
	 */
	public Hashtable<Integer, CommunicationInterface> getNetwork() {
		return network;
	}
	
	/**
	 * Update the new CommunicationNetwork Node to it's appropriate
	 * locations on the Evaluation tool.
	 * @param nodeId
	 * @param commNetwork
	 */
	public void add(int nodeId, CommunicationInterface commNetwork) {
			
		Integer node = new Integer(nodeId);
		HashMap<Integer, String> connection = new HashMap<Integer, String>();
		network.put(node, commNetwork);

		etool.getEnetwork().putAll(network);

		topology.put(node, connection);
		connection.put(node, new String("0"));
		//networkActionPanel.getNodeOneComboBox().addItem(Integer.toString(nodeId));
		getDisplayNetworksPanel().displayCommNetwork(nodeId);
		getMessagePanel().getTargetNodeComboBox().addItem(Integer.toString(nodeId));
		getMessagePanel().getSrcNodeComboBox().addItem(Integer.toString(nodeId));	
		networkStatus.getNodeFromComboBox().addItem(Integer.toString(nodeId));
		
		
		// @SuppressWarnings("rawtypes") are for these values
		Set<Integer> set = topology.keySet();
		Iterator<Integer> iter = set.iterator();
		Integer key;
		
		Iterator<Integer> innerIter;
		
		// populate the topology
		while(iter.hasNext()) {
			key = iter.next();
			
			innerIter = set.iterator();
			while(innerIter.hasNext()) {
				topology.get(innerIter.next()).put(key, new String("0"));
			}
		}
		/*****Get all the CNN*/
		etool.getEtopology().putAll(topology);
		etool.getConectionStatus().displayCommNetwork(etool.getEtopology());
		keyBaseSet(nodeId);

	}
	
	
	/*****keybasemap init****************/
	public void keyBaseSet(int nodeId){
		String key = "";
		if(nodeId > 1)
		{
			for(int i = nodeId -1; i >= 1; i --)
			{
				key = String.valueOf(i) + String.valueOf(nodeId);
				etool.getKeyBaseMap().put(key, 1);
			}
		}
	}

	@Override
	public synchronized void SendData(CommObj commObj) {
		getDisplayTrafficPanel().displaySend(commObj);
	}

	@Override
	public void ReceiveData(final CommObj commObj) {
		etool.display(commObj);
	}
	
	/**
	 * Just Set everything to 0 or null to simulate 
	 * deleted message.
	 * @param commObj
	 */
	private void deleteCommObj(CommObj commObj) {
		commObj.setAck(false);
		commObj.setData(null);
		commObj.setFieldType("");
		commObj.setNodeType(0);
		commObj.setPriority(-1);
		commObj.setSrcNode(0);
		commObj.setTargetNode(0);
		commObj.setTimeRec(0);
		commObj.setTimeSent(0);
	}
	/**
	 * Get the topology
	 * @return
	 */
	public HashMap<Integer, HashMap<Integer, String>> getTopology() {
		return topology;
	}
	/**
	 * This method is used for the Evaluation tool to 
	 * send data to the source node.
	 */
	public void ESend(final CommObj commObj) {
		// spawn off a new thread to do the send
		new Thread(new Runnable() {
			public void run() {
				try {
					Thread.sleep(Node.latency);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				getDisplayTrafficPanel().displaySend(commObj);
				
				network.get(Integer.parseInt(Integer.toString(commObj.getSrcNode()))).receiveData(commObj);
			}
		}).start();
	}
}

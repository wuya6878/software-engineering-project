package edu.neu.E.DataGenerate;

import java.util.LinkedList;

/**
 * 
 * @author hermida
 *
 * @param <E>
 */
public class MyLinkedList<E> extends LinkedList<E> {

	private static final long serialVersionUID = 1L;
	
	/**
	 * Avoid Duplicates
	 * @param E
	 * @return 
	 */
	public boolean add(E e) {
		if(!super.contains(e)) {
			super.add(e);
			return true;
		}
		return false;
	}
}

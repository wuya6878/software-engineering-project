package edu.neu.E.DataGenerate;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import edu.neu.d1.data.CommObj;

/**
 * 
 * @author hermida
 *
 */
public class DisplayTrafficPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private JTextArea sendTextArea;
	private JTextArea receiveTextArea;
	
	public DisplayTrafficPanel() {

		sendTextArea = new JTextArea("Sending:\n\n");
		sendTextArea.setEditable(false);
		
		//receiveTextArea = new JTextArea("Receiving:\n\n");
		//receiveTextArea.setEditable(false);
		
		setLayout(new GridLayout(1,1,3,4));
		add(new JScrollPane(sendTextArea));
		//add(new JScrollPane(receiveTextArea));
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Network Traffic");
		
		// set the border
		setBorder(titled);

	}
	
	/**
	 * Display the CommObj on the text field.
	 * @param obj
	 */
	public synchronized void displaySend(CommObj obj) {
		String message = new String("MsgId: " + obj.getMsgID() + " " +
									"NodeType: " + obj.getNodeType() + " " +
									"FieldType: " + obj.getFieldType() + " " +
									"Data: " + obj.getData() + " " +
									"TimeSent: " + obj.getTimeSent() + " " +
									"TimeRec: " + obj.getTimeRec() + " " +
									"Priority: " + obj.getPriority() + " " +
									"Ack: " + obj.getAck() + " " +
									"SrcNode: " + obj.getSrcNode() + " " +
									"TargetNode: " + obj.getTargetNode() + "\n");
		
		sendTextArea.append(message);
	}
	
	/**
	 * Display the CommObj on the text field.
	 * @param obj
	 */
	/*public synchronized void displayReceive(CommObj obj) {
		String message = new String("MsgId: " + obj.getMsgID() + " " +
									"NodeType: " + obj.getNodeType() + " " +
									"FieldType: " + obj.getFieldType() + " " +
									"Data: " + obj.getData() + " " +
									"TimeSent: " + obj.getTimeSent() + " " +
									"TimeRec: " + obj.getTimeRec() + " " +
									"Priority: " + obj.getPriority() + " " +
									"Ack: " + obj.getAck() + " " +
									"SrcNode: " + obj.getSrcNode() + " " +
									"TargetNode: " + obj.getTargetNode() + "\n");
		
		receiveTextArea.append(message);
	}*/
}

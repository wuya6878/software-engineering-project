package edu.neu.E.DataGenerate;

import edu.neu.d1.data.CommObj;

/**
 * 
 * @author hermida
 *
 */
public interface EInterface {
	/**
	 * E interface for send data.
	 * @param commObj
	 */
	public void SendData(CommObj commObj);
	
	/**
	 * E interface for receive data.
	 * @param commObj
	 */
	public void ReceiveData(CommObj commObj);
	
	
}

package edu.neu.E.DataG;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

/**
 * 
 * @author hermida
 *
 */
public class DisplayNetworksPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private JTextArea commNetworkTextArea;
	private int row = 20;
	private int col = 15;

	public DisplayNetworksPanel() {

		commNetworkTextArea = new JTextArea(row,col);
		commNetworkTextArea.setEditable(false);
		
		add(new JScrollPane(commNetworkTextArea));
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Communication Networks");
		
		// set the border
		setBorder(titled);

	}
	
	/**
	 * Display the CommObj on the text field.
	 * @param obj
	 */
	public synchronized void displayCommNetwork(int nodeId) {
		String network = new String("Communication Network " + nodeId + "\n");
		
		commNetworkTextArea.append(network);
	}
}

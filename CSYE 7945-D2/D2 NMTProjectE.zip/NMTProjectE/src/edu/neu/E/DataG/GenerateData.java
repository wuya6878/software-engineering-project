package edu.neu.E.DataG;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JFrame;

import edu.neu.d1.communication.CommunicationNetworkNode;
import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;

/**
 * 
 * @author hermida
 *
 */
@SuppressWarnings("rawtypes")
public class GenerateData extends Node implements EInterface {

	private static final long serialVersionUID = 1L;
	public static int uniqueNodeId;
	
	private NetworkActionPanel networkActionPanel;
	private MessagePanel messagePanel;
	private DisplayTrafficPanel trafficPanel;
	private DisplayNetworksPanel networksPanel;
	
	// Keep a list of all the networks created
	private Hashtable<Integer, CommunicationNetworkNode> network;
	
	// store the topology
	private HashMap<Integer, HashMap<Integer, String>> topology;
	
	/**
	 * Constructor
	 */
	public GenerateData() {
		super("D1 Evalutation Tool Simulation");
		// set the first node id to 1
		uniqueNodeId = 1;
		
		// create the panels
		networkActionPanel = new NetworkActionPanel(this);
		messagePanel = new MessagePanel(this);
		trafficPanel = new DisplayTrafficPanel();
		networksPanel = new DisplayNetworksPanel();
		
		// initialize the Hash
		network = new Hashtable<Integer, CommunicationNetworkNode>();
		topology = new HashMap<Integer, HashMap<Integer, String>>();

		// add the panels to the frame
		add(networkActionPanel, BorderLayout.NORTH);
		add(trafficPanel, BorderLayout.CENTER);
		add(networksPanel, BorderLayout.EAST);
		add(messagePanel, BorderLayout.SOUTH);
		
		// pack the frame
		pack();
		
		
		// only the EvaluationTool can terminate the application
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	/**
	 * Get the NetworkActionPanel
	 */
	public NetworkActionPanel getNetworkActionPanel() {
		return networkActionPanel;
	}
	
	/**
	 * getter for the message panel
	 * @return DisplayPanel
	 */
	public MessagePanel getMessagePanel() {
		return messagePanel;
	}
	
	/**
	 * Getter for display networks panel
	 * @return
	 */
	public DisplayNetworksPanel getDisplayNetworksPanel() {
		return networksPanel;
	}
	
	/**
	 * Getter for display traffic panel
	 * @return
	 */
	public DisplayTrafficPanel getDisplayTrafficPanel() {
		return trafficPanel;
	}
	
	/**
	 * Return a CommunicationNetworkNode reference
	 * @param nodeId
	 * @return communicationNetworkNode, null otherwise
	 */
	public CommunicationNetworkNode getCommunicationNetwork(int nodeId) {
		Integer id = new Integer(nodeId);
		if(network.containsKey(id)) {
			return network.get(id);
		} else {
			return null;
		}
	}
	
	public CommunicationNetworkNode getCommunicationNetwork(Integer nodeId) {
		if(network.containsKey(nodeId)) {
			return network.get(nodeId);
		} else {
			return null;
		}
	}
	/**
	 * get the list of networks.
	 * @return
	 */
	public Hashtable<Integer, CommunicationNetworkNode> getNetwork() {
		return network;
	}
	
	/**
	 * Update the new CommunicationNetwork Node to it's appropriate
	 * locations on the Evaluation tool.
	 * @param nodeId
	 * @param commNetwork
	 */
	public void add(int nodeId, CommunicationNetworkNode commNetwork) {
			
		Integer node = new Integer(nodeId);
		HashMap<Integer, String> connection = new HashMap<Integer, String>();
		network.put(node, commNetwork);
		topology.put(node, connection);
		connection.put(node, new String("0"));
		networkActionPanel.getDeactivateComboBox().addItem(Integer.toString(nodeId));
		networkActionPanel.getNodeOneComboBox().addItem(Integer.toString(nodeId));
		networkActionPanel.getNodeTwoComboBox().addItem(Integer.toString(nodeId));
		getDisplayNetworksPanel().displayCommNetwork(nodeId);
		getMessagePanel().getTargetNodeComboBox().addItem(Integer.toString(nodeId));
		getMessagePanel().getSrcNodeComboBox().addItem(Integer.toString(nodeId));
		
		
		// @SuppressWarnings("rawtypes") are for these values
		Integer temp1;
		Set set = topology.keySet();
		Iterator iter = set.iterator();
		Integer key;
		
		Iterator innerIter;
		
		// add the new node to the topology
		while(iter.hasNext()) {
			key = (Integer)iter.next();
			
			topology.get(key).put(node, new String("0"));
		}
		
		// reset the iterator
		iter = set.iterator();
		
		// populate the topology
		while(iter.hasNext()) {
			// outer key
			key = (Integer)iter.next();
			
			innerIter = set.iterator();
			while(innerIter.hasNext()) {
				
				// inner key
				temp1 = (Integer)innerIter.next();
				
				// if the inner key equals the new node and 
				// the outer key does not equal the new node
				if(temp1.equals((Object)node) && !key.equals((Object)node)) {
					topology.get(temp1).put(key, new String("0"));
				}
				else if(topology.size() != topology.get(key).size()) {
					continue;
				}
			}
		}
	}
	/**
	 * deactivate a node
	 * @param nodeId
	 */
	public void deactivateNode(Integer nodeId) {
		// @SuppressWarnings("rawtypes") are for these values
		Set set = topology.keySet();
		Iterator iter = set.iterator();
		
		Integer key;
		
		// populate the topology
		while(iter.hasNext()) {
			key = Integer.parseInt(iter.next().toString());
			topology.get(key).remove(nodeId);
		}
	}
	
	
	/**
	 * deactivate a node
	 * @param nodeId
	 */
	public void activateNode(Integer nodeId) {
		// @SuppressWarnings("rawtypes") are for these values
		Set set = topology.keySet();
		Iterator iter = set.iterator();
		
		Integer key;
		
		// populate the topology
		while(iter.hasNext()) {
			key = Integer.parseInt(iter.next().toString());
			topology.get(key).put(nodeId, new String("0"));
		}
	}
	
	/**
	 * This is the global interface that all Communication Network
	 * Nodes use to send their data to the target destination.
	 */
	@Override
	public synchronized void SendData(CommObj commObj) {
		getDisplayTrafficPanel().displaySend(commObj);
		
	}

	@Override
	public void ReceiveData(final CommObj commObj) {
		getDisplayTrafficPanel().displayReceive(commObj);
		// *** send to target node for testing purposes ***/
		// spawn off a new thread to do the send
		new Thread(new Runnable() {
			public void run() {
				try {
					Thread.sleep(Node.latency);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				
				// check to see if the link is down between source and target
				if(commObj != null) {
					if(topology.get((Integer)commObj.getSrcNode()).containsKey((Integer)commObj.getTargetNode())) {	
						// display in the send traffic
						getDisplayTrafficPanel().displaySend(commObj);
						// send it to the target node.
						network.get(Integer.parseInt(Integer.toString(commObj.getTargetNode()))).receiveData(commObj);
					} else {
						
						deleteCommObj(commObj);
						// display in the receive traffic
						getDisplayTrafficPanel().displayReceive(commObj);
					}
				}
			}
		}).start();
		/*
		if(commObj.getTimeRec() != 0) {
			// send data to it's target node
			
		}*/
		
	}
	
	/**
	 * Just Set everything to 0 or null to simulate 
	 * deleted message.
	 * @param commObj
	 */
	private void deleteCommObj(CommObj commObj) {
		commObj.setAck(false);
		commObj.setData(null);
		commObj.setFieldType("");
		commObj.setNodeType(0);
		commObj.setPriority(-1);
		commObj.setSrcNode(0);
		commObj.setTargetNode(0);
		commObj.setTimeRec(0);
		commObj.setTimeSent(0);
	}
	/**
	 * Get the topology
	 * @return
	 */
	public HashMap<Integer, HashMap<Integer, String>> getTopology() {
		return topology;
	}
	/**
	 * This method is used for the Evaluation tool to 
	 * send data to the source node.
	 */
	public void ESend(final CommObj commObj) {
		// spawn off a new thread to do the send
		new Thread(new Runnable() {
			public void run() {
				try {
					Thread.sleep(Node.latency);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				// display in the send traffic
				getDisplayTrafficPanel().displaySend(commObj);
				
				// send it to the src node.
				network.get(Integer.parseInt(Integer.toString(commObj.getSrcNode()))).receiveData(commObj);
			}
		}).start();
	}
}

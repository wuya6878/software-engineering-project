package edu.neu.E.DataG;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;

/**
 * 
 * @author hermida
 *
 */
public class MessagePanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private static int messageId = 1;
	private GenerateData eTool;
	
	private JTextField latency;
	private DefaultComboBoxModel nodeTypeComboBoxModel;
	private final String[] nodeTypeList = new String[]{"0","1","2"}; 
	private JComboBox nodeTypeComboBox;
	private DefaultComboBoxModel fieldTypeComboBoxModel;
	private String[] fieldTypeList;
	private JComboBox fieldTypeComboBox;
	private JTextField data;
	private DefaultComboBoxModel priorityComboBoxModel;
	private final String[] priorityList = new String[]{"1","2","3","4","5","6","7","8","9","10"};
	private JComboBox priorityComboBox;
	private DefaultComboBoxModel targetNodeComboBoxModel;
	private String[] targetNodeList;
	private JComboBox targetNodeComboBox;
	private DefaultComboBoxModel srcNodeComboBoxModel;
	private String[] srcNodeList;
	private JComboBox srcNodeComboBox;
	private JButton send;
	
	public MessagePanel(final GenerateData eTool) {
		this.eTool = eTool;
		//  initialize the instance variables 
		nodeTypeComboBoxModel = new DefaultComboBoxModel(nodeTypeList);
		nodeTypeComboBox = new JComboBox(nodeTypeComboBoxModel);
		
		nodeTypeComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				fieldTypeComboBox.removeAllItems();
				
				if(nodeTypeComboBox.getSelectedIndex() == 0) {
					fieldTypeList = new String[]{"Name", "Address", "DateOfBirth", "PhoneNumber", 
							"Friends", "Occupation", "StatusBlurb"};
				} else if (nodeTypeComboBox.getSelectedIndex() == 1){
					fieldTypeList = new String[]{"MedicalInfo", "GPSLocation", "ICEContacts"};					
				} else {
					fieldTypeList = new String[]{};
				}
				
				for(String s: fieldTypeList) {
					fieldTypeComboBox.addItem(s);
				}
			}	
		});
		
		fieldTypeList = new String[]{"Name", "Address", "DateOfBirth", "PhoneNumber", 
				"Friends", "Occupation", "StatusBlurb"};
		fieldTypeComboBoxModel = new DefaultComboBoxModel(fieldTypeList);
		fieldTypeComboBox = new JComboBox(fieldTypeComboBoxModel);
		data = new JTextField(10); // set the text field 10 columns in width
		priorityComboBoxModel = new DefaultComboBoxModel(priorityList);
		priorityComboBox = new JComboBox(priorityComboBoxModel);
		targetNodeList = new String[]{};
		targetNodeComboBoxModel = new DefaultComboBoxModel(targetNodeList);
		targetNodeComboBox = new JComboBox(targetNodeComboBoxModel);
		srcNodeList = new String[]{};
		srcNodeComboBoxModel = new DefaultComboBoxModel(srcNodeList);
		srcNodeComboBox = new JComboBox(srcNodeComboBoxModel);
		latency = new JTextField(4);
		
		add(new JLabel("Latency"));
		add(latency);
		add(new JLabel("NodeType:"));
		add(nodeTypeComboBox);
		add(new JLabel("Field:"));
		add(fieldTypeComboBox);
		add(new JLabel("Data:"));
		add(data);
		add(new JLabel("Priority:"));
		add(priorityComboBox);
		add(new JLabel("Source:"));
		add(srcNodeComboBox);
		add(new JLabel("Target:"));
		add(targetNodeComboBox);

		send = new JButton("Send");
		
		send.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				final CommObj obj = new CommObj();
				
				if(latency.getText().equals("") ) {
					Node.latency = 0;
				} else {
					Node.latency = Integer.parseInt(latency.getText());
				}
				obj.setMsgID(MessagePanel.messageId++);
				obj.setNodeType(Integer.parseInt(nodeTypeComboBox.getSelectedItem().toString()));
				obj.setFieldType(fieldTypeComboBox.getSelectedItem().toString());
				obj.setData(data.getText());
				obj.setPriority(Integer.parseInt(priorityComboBox.getSelectedItem().toString()));
				obj.setTimeSent(System.nanoTime());
				obj.setTimeRec(0);
				obj.setAck(false);
				obj.setTargetNode(Integer.parseInt(targetNodeComboBox.getSelectedItem().toString()));
				obj.setSrcNode(Integer.parseInt(srcNodeComboBox.getSelectedItem().toString()));
				
				// spawn off a new thread to do the send
				new Thread(new Runnable() {
					public void run() {
						try {
							Thread.sleep(Node.latency);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
						
						eTool.ESend(obj);
					}
				}).start();
			}
		});
		
		add(send);
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Send Messages");
		
		// set the border
		setBorder(titled);
	}

	/**
	 * 
	 * @return
	 */
	public JComboBox getTargetNodeComboBox() {
		return targetNodeComboBox;
	}


	/**
	 * 
	 * @return
	 */
	public JComboBox getSrcNodeComboBox() {
		return srcNodeComboBox;
	}	
}

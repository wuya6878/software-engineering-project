package edu.neu.E.Evaluation;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import edu.neu.E.DataGenerate.EInterface;
import edu.neu.E.DataGenerate.GenerateData;
import edu.neu.E.Report.Report;
//simport edu.neu.E.Report.Report;
import edu.neu.d1.data.CommObj;

public class NetworkOperation extends JPanel{

	/**
	 * author Bon
	 */
	private static final long serialVersionUID = 1L;
	private JButton linkDownButton;
	//private JButton discard;
	private ETool etool;
	private int sourceSelect;
	private int targetSelect;
	private JButton Compare;
	private Report report;
	
	private JComboBox source;
	//private String[] sourceNodeList;
	//private DefaultComboBoxModel nodeFromComboBoxModel;
	
	private JComboBox target;
	//private String[] targetNodeList;
	//private DefaultComboBoxModel nodeToComboBoxMode2;
	
	private JButton linkUpButton;

	
	public NetworkOperation(final ETool etool)
	{
		this.etool = etool;
		source = new JComboBox();
		target = new JComboBox();
		linkDownButton = new JButton("Link Down");
		linkUpButton = new JButton("Link Up");
		//discard = new JButton("discard");
		Compare = new JButton("Compare");
		report = new Report();

		
		//sourceNodeList = new String[]{};
		//nodeFromComboBoxModel = new DefaultComboBoxModel(sourceNodeList);
		//source = new JComboBox(nodeFromComboBoxModel);
		
		add(new JLabel("Source"));
		add(source);
		add(new JLabel("Target"));
		add(target);
		
		
		
		source.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event) 
			{
				target.removeAllItems();
				int index = source.getSelectedIndex();
				sourceSelect = index + 1;
				//System.out.print(sourceSelect+"\n");
				
				for(int i = 0; i < source.getItemCount(); i++)
				{
					if(index != i)
					{
						getTarget().addItem(source.getItemAt(i));
					}
				}	
			}	
		});
		
		target.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent event) 
			{
				if(target.getSelectedItem() != null)
				{
					targetSelect = Integer.parseInt(target.getSelectedItem().toString());
					String combineKey = etool.getCombinedKey(sourceSelect, targetSelect); 
				    if(etool.getKeyBaseMap().get(combineKey).toString().equals("1"))
				    {
				    	linkDownButton.setEnabled(true);
				    	linkUpButton.setEnabled(false);
				    	//discard.setEnabled(false);
				    	//etool.getEoperation().getSend().setEnabled(true);
				    }
				    else
				    {
				    	linkDownButton.setEnabled(false);
				    	linkUpButton.setEnabled(true);
				    }
				}
			}	
		});
		
		
		linkDownButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent event)
			{
				synchronized(this) 
				{
					etool.getEtopology().get(Integer.parseInt(source.getSelectedItem().toString())).remove(Integer.parseInt(target.getSelectedItem().toString()));
					etool.getEtopology().get(Integer.parseInt(target.getSelectedItem().toString())).remove(Integer.parseInt(source.getSelectedItem().toString()));
					etool.getConnectionStatus().getConnectionStatus().setText(null);
					Set<Integer> set = etool.getEtopology().keySet();
					Iterator<Integer> iter = set.iterator();
					Integer key;
					for(Integer k: set)
					{
						for(Integer j : etool.getEtopology().get(k).keySet())
						{
							if(j > k )
							{
								String network = new String("Communication Network " + k.toString() + 
										"<--->" + "Communication Network" +j + "\n");
								etool.getConnectionStatus().getConnectionStatus().append(network);
							}
						}	
					}
					String combineKey = etool.getCombinedKey(sourceSelect, targetSelect); 
				    etool.getKeyBaseMap().remove(combineKey);
				    etool.getKeyBaseMap().put(combineKey, 0);
				    linkUpButton.setEnabled(true);
				    linkDownButton.setEnabled(false);
				}
			}
		});
				
		//linkDownButton.setEnabled(false);
		
		linkUpButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent event) 
			{
				etool.getConnectionStatus().getConnectionStatus().setText(null);
				Set<Integer> set = etool.getEtopology().keySet();
				Iterator<Integer> iter = set.iterator();
				Integer key;
				
				// change the network topology to reflect a link up
				synchronized(this) 
				{
					etool.getEtopology().get(Integer.parseInt(source.getSelectedItem().toString())).put(Integer.parseInt(target.getSelectedItem().toString()), new String("0"));
					etool.getEtopology().get(Integer.parseInt(target.getSelectedItem().toString())).put(Integer.parseInt(source.getSelectedItem().toString()), new String("0"));
				}
				linkDownButton.setEnabled(true);
				linkUpButton.setEnabled(false);
				for(Integer k: set)
				{
					for(Integer j : etool.getEtopology().get(k).keySet())
					{
						if(j > k )
						{
							String network = new String("Communication Network " + k.toString() + 
									"<--->" + "Communication Network" +j + "\n");
							etool.getConnectionStatus().getConnectionStatus().append(network);
						}
					}
				}
				String combineKey = etool.getCombinedKey(sourceSelect, targetSelect);
			    etool.getKeyBaseMap().remove(combineKey);
			    etool.getKeyBaseMap().put(combineKey, 1);
			    linkDownButton.setEnabled(true);
			    linkUpButton.setEnabled(false);
			}
		});
		
		Compare.addActionListener(new ActionListener() 
		{
			
			int i = 0;
			public void actionPerformed(ActionEvent event)
			{
				EventQueue.invokeLater(new Runnable() {
					public void run() {
						report.setVisible(true);
						//getReport().getButtonPanel().getMegID().removeAllItems();
						for(CommObj commObj: etool.getExpectedList())
						{
							int j = 0;
							for(i = 0; i <getReport().getButtonPanel().getMegID().getItemCount(); i ++)
							{
								if(commObj.getMsgID() == Integer.valueOf(getReport().getButtonPanel().getMegID().getItemAt(i).toString()))
								{
									j = 1;
								}
							}
							if(j == 0 && i == getReport().getButtonPanel().getMegID().getItemCount())
							{
								getReport().getButtonPanel().getMegID().addItem(commObj.getMsgID());
							}
						}
					}
				});
			}
		});


		add(linkDownButton);
		add(linkUpButton);
		add(Compare);

		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Network Status");
		
		// set the border
		setBorder(titled);
		
		
	}
	
	public ArrayList<String> filtDate(ArrayList<CommObj> list)
	{
		ArrayList<String> tempList = new ArrayList<String>();
		for(CommObj commObj: list)
		{
			if(!tempList.contains(String.valueOf(commObj.getMsgID())))
					{
				tempList.add(String.valueOf(commObj.getMsgID()));
					}		
		}
		return tempList;
	}
	
	
	public JButton getLinkDownButton() {
		return linkDownButton;
	}


	public void setLinkDownButton(JButton linkDownButton) {
		this.linkDownButton = linkDownButton;
	}


	public JComboBox getNodeFromComboBox() {
		return source;
	}


	public void setNodeFromComboBox(JComboBox nodeFromComboBox) {
		this.source = nodeFromComboBox;
	}


	public JComboBox getNodeToComboBox() {
		return target;
	}


	public void setNodeToComboBox(JComboBox nodeToComboBox) {
		this.target = nodeToComboBox;
	}

	public JButton getLinkUpButton() {
		return linkUpButton;
	}


	public void setLinkUpButton(JButton linkUpButton) {
		this.linkUpButton = linkUpButton;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public JComboBox getSource() {
		return source;
	}


	public void setSource(JComboBox source) {
		this.source = source;
	}


	public JComboBox getTarget() {
		return target;
	}


	public void setTarget(JComboBox target) {
		this.target = target;
	}

	public Report getReport() {
		return report;
	}

	public void setReport(Report report) {
		this.report = report;
	}

}

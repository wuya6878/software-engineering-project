package edu.neu.E.Evaluation;

import java.awt.GridLayout;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class ConnectionStatus extends JPanel{

	/**
	 * author Bon
	 */
	private static final long serialVersionUID = 1L;

	private JTextArea connectionStatus;
	
	public ConnectionStatus(){
		
		connectionStatus = new JTextArea(20,40);
		
		add(new JScrollPane(connectionStatus));
		setLayout(new GridLayout(1,1,2,4));
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Network Status");
		// set the border
		setBorder(titled);
	}
	
	public synchronized void displayCommNetwork(HashMap<Integer, HashMap<Integer, String>> etopology) {
		connectionStatus.setText(null);
		Set<Integer> set = etopology.keySet();
		Iterator<Integer> iter = set.iterator();
		Integer key;
		for(Integer k: set){
			for(Integer j : etopology.get(k).keySet())
			{
				if(j > k ){
					String network = new String("Communication Network " + k.toString() + 
							"<--->" + "Communication Network" +j + "\n");
					//ConnectionStatus.paintImmediately(getBounds());
					connectionStatus.append(network);
				}
			}		
		}

	}

	public JTextArea getConnectionStatus() {
		return connectionStatus;
	}

	public void setConnectionStatus(JTextArea connectionStatus) {
		this.connectionStatus = connectionStatus;
	}
	
	
}

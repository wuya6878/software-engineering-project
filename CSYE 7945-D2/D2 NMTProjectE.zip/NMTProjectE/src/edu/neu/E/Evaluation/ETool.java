package edu.neu.E.Evaluation;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JTextPane;

import edu.neu.E.DataGenerate.EInterface;
import edu.neu.E.DataGenerate.GenerateData;
import edu.neu.d1.communication.CommunicationInterface;
import edu.neu.d1.communication.CommunicationNetworkNode;
import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;

@SuppressWarnings("serial")
public class ETool extends Node{

	/**
	 * 
	 */
	private NetworkOperation epanel;
	private ConnectionStatus conectionStatus;
	private GenerateData evaluationTool;
	private DataInfo datainfo;
	private ArrayList<CommObj> inputList;
	private ArrayList<CommObj> expectedList;
	private ArrayList<CommObj> outputList;
	private ArrayList<CommObj> discardList;
	private ArrayList<CommObj> totalList;

	private HashMap<String, Object> keyBaseMap;
	
	private Hashtable<Integer, CommunicationInterface> enetwork;
	
	// store the topology
	private HashMap<Integer, HashMap<Integer, String>> etopology; 
	
	public ETool() {
		super("E Tool");
		// TODO Auto-generated constructor stub
		datainfo = new DataInfo();
		epanel = new NetworkOperation(this);
		conectionStatus= new ConnectionStatus();
		enetwork = new Hashtable<Integer, CommunicationInterface>();
		etopology = new HashMap<Integer, HashMap<Integer, String>>();
		inputList = new ArrayList<CommObj>();
		discardList = new ArrayList<CommObj>();
		expectedList = new ArrayList<CommObj>();
		outputList = new ArrayList<CommObj>();
		keyBaseMap = new HashMap<String, Object>();
		totalList = new ArrayList<CommObj>();
		//cnn = new CommunicationNetworkNode(GenerateData.uniqueNodeId++,this);
		
		add(epanel, BorderLayout.NORTH);
		add(datainfo, BorderLayout.CENTER);
		//add(eoperation, BorderLayout.SOUTH);
		add(conectionStatus, BorderLayout.EAST);
		pack();		
	}
	
	public void display(CommObj commObj)
	{
		String isLinkUp = checkNetworkStatus(commObj);
		if(isLinkUp.equals("1"))
		{
			routeData(commObj);
			//sendAck();
			
		}
		if(isLinkUp.equals("0"))
		{
			CommObj linkdownObj = new CommObj();
			linkdownObj = (CommObj)commObj.clone();
			discardList.add(linkdownObj);
			getDatainfo().displayLinkDown(linkdownObj);
		}
	}
	
	public String checkNetworkStatus(CommObj commObj)
	{
		int source = commObj.getSrcNode();
		int target = commObj.getTargetNode();
		return keyBaseMap.get(getCombinedKey(source, target)).toString();
	}

	public String getCombinedKey(int sourceSelect, int targetSelect)
	{
		String combineKey;
		if(sourceSelect < targetSelect)
		{
			combineKey = String.valueOf(sourceSelect)+String.valueOf(targetSelect);			
		}
		else
		{
			combineKey = String.valueOf(targetSelect)+String.valueOf(sourceSelect);			
		}
		return combineKey;
	}
	
	public void routeData(CommObj commObj) {
		
		if(getInputList().size() == 0)
		{
			getInputList().add(commObj);
			getDatainfo().displaySend(commObj);
			
			CommObj expectcObj = new CommObj();
			expectcObj = (CommObj)commObj.clone();
			expectcObj.setSrcNode(commObj.getTargetNode());
			expectcObj.setTargetNode(commObj.getSrcNode());
			expectcObj.setAck(true);
			getExpectedList().add(expectcObj);
			getEpanel().getReport().getButtonPanel().setExpected(expectedList);
			getDatainfo().displayExpected(expectcObj);
			enetwork.get(Integer.parseInt(Integer.toString(commObj.getTargetNode()))).receiveData(commObj);
		}
		else if(getInputList().get(0).getMsgID() == commObj.getMsgID() && getInputList().get(0).getSrcNode() == commObj.getTargetNode() && 
				getInputList().get(0).getTargetNode() == commObj.getSrcNode())
		{
			getOutputList().add(commObj); 
			getDatainfo().displayOutput(commObj);
			getInputList().clear();
			enetwork.get(Integer.parseInt(Integer.toString(commObj.getTargetNode()))).receiveData(commObj);
			getEpanel().getReport().getButtonPanel().setOutput(outputList);
		}
		
/*		if(getInputList().size() == 0)
		{
			getInputList().add(commObj);
			getDatainfo().displaySend(commObj);
			
			CommObj expectcObj = new CommObj();
			expectcObj = (CommObj)commObj.clone();
			expectcObj.setAck(true);
			getExpectedList().add(expectcObj);
			getDatainfo().displayExpected(expectcObj);
			
			enetwork.get(Integer.parseInt(Integer.toString(commObj.getTargetNode()))).receiveData(commObj);
		}
		else
		{
			for(CommObj commobj : inputList)
			{
				if(commobj.getMsgID() == commObj.getMsgID() &&
				   commobj.getSrcNode() == commObj.getTargetNode() && 
				   commobj.getTargetNode() == commObj.getSrcNode()
				   )
				{
					getOutputList().add(commObj); 
					getDatainfo().displayOutput(commObj);
					getInputList().clear();
					enetwork.get(Integer.parseInt(Integer.toString(commObj.getTargetNode()))).receiveData(commObj);
				}
				else
				{
					getInputList().add(commObj);
					getDatainfo().displaySend(commObj);
					CommObj expectcObj = new CommObj();
					expectcObj = (CommObj)commObj.clone();
					expectcObj.setAck(true);
					getExpectedList().add(expectcObj);
					getDatainfo().displayExpected(expectcObj);
					enetwork.get(Integer.parseInt(Integer.toString(commObj.getTargetNode()))).receiveData(commObj);
				}
			}
		}*/
		
		

		/* call Communication Interface*/
		
		
		//cnn.receiveData(routeCOb);
		/* **********************/
		
	}
	
	public DataInfo getDatainfo() {
		return datainfo;
	}

	public void setDatainfo(DataInfo datainfo) {
		this.datainfo = datainfo;
	}

	public NetworkOperation getEpanel() {
		return epanel;
	}

	public void setEpanel(NetworkOperation epanel) {
		this.epanel = epanel;
	}

	public GenerateData getEvaluationTool() {
		return evaluationTool;
	}

	public void setEvaluationTool(GenerateData evaluationTool) {
		this.evaluationTool = evaluationTool;
	}

	public ConnectionStatus getConnectionStatus() {
		return conectionStatus;
	}

	public void setConnectionStatus(ConnectionStatus coonectionStatus) {
		this.conectionStatus = coonectionStatus;
	}

	public ConnectionStatus getConectionStatus() {
		return conectionStatus;
	}

	public void setConectionStatus(ConnectionStatus conectionStatus) {
		this.conectionStatus = conectionStatus;
	}

	public Hashtable<Integer, CommunicationInterface> getEnetwork() {
		return enetwork;
	}

	public void setEnetwork(Hashtable<Integer, CommunicationInterface> enetwork) {
		this.enetwork = enetwork;
	}

	public HashMap<Integer, HashMap<Integer, String>> getEtopology() {
		return etopology;
	}

	public void setEtopology(HashMap<Integer, HashMap<Integer, String>> etopology) {
		this.etopology = etopology;
	}

	public ArrayList<CommObj> getInputList() {
		return inputList;
	}

	public void setInputList(ArrayList<CommObj> inputList) {
		this.inputList = inputList;
	}

	public ArrayList<CommObj> getExpectedList() {
		return expectedList;
	}

	public void setExpectedList(ArrayList<CommObj> expectedList) {
		this.expectedList = expectedList;
	}

	public ArrayList<CommObj> getOutputList() {
		return outputList;
	}

	public void setOutputList(ArrayList<CommObj> outputList) {
		this.outputList = outputList;
	}

	public HashMap<String, Object> getKeyBaseMap() {
		return keyBaseMap;
	}

	public void setKeyBaseMap(HashMap<String, Object> keyBaseMap) {
		this.keyBaseMap = keyBaseMap;
	}
	public ArrayList<CommObj> getTotalList() {
		return totalList;
	}

	public void setTotalList(ArrayList<CommObj> totalList) {
		this.totalList = totalList;
	}
}

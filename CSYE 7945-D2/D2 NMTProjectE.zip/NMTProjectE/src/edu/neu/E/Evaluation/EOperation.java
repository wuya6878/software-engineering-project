/*package edu.neu.E.Evaluation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import edu.neu.E.DataGenerate.MessagePanel;
import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;

public class EOperation extends JPanel{
	private static final long serialVersionUID = 1L;

	private JComboBox nodeTargetComboBox;
	private JButton Send;
	private JButton Compare;
	private JButton SendAck;
	private String TargetNode;
	private ETool etool;
	
	
	public EOperation(final ETool etool){
		this.etool = etool;
		
	nodeTargetComboBox = new JComboBox();
		Send = new JButton("Send");
		SendAck = new JButton("SendAck");
		Compare = new JButton("Compare");
		
		add(new JLabel("TargetNode"));
		add(nodeTargetComboBox);
		
		Send.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				etool.routeData();
			}
		});
		
		SendAck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				etool.sendAck();
			}
		});
		
	
		
		
		add(Send);
		add(SendAck);
		add(Compare);
		//setLayout(new GridLayout(1,1));
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "E Operation");
		
		// set the border
		setBorder(titled);
	}

	public JButton getSend() {
		return Send;
	}

	public void setSend(JButton send) {
		Send = send;
	}

	public JButton getCompare() {
		return Compare;
	}

	public void setCompare(JButton compare) {
		Compare = compare;
	}

	public JComboBox getNodeTargetComboBox() {
		return nodeTargetComboBox;
	}

	public void setNodeTargetComboBox(JComboBox nodeTargetComboBox) {
		this.nodeTargetComboBox = nodeTargetComboBox;
	}
	
}
*/
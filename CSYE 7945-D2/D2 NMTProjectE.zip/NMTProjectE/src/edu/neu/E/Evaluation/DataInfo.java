package edu.neu.E.Evaluation;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;

public class DataInfo extends JPanel{

	/**
	 * author Bon
	 */
	private static final long serialVersionUID = 1L;
	private JTextArea Input;
	private JTextArea Expected;
	private JTextArea Output;
	private JTextArea Linkdowninput;

	
	public DataInfo(){
		Input = new JTextArea("LinkUpInput:\n",5,40);
		Expected = new JTextArea("LinkUpExpected:\n",5,40);
		Output = new JTextArea("LinkUpOutput:\n", 5,40);
		Linkdowninput = new JTextArea("LinkdownInput:\n", 5,40);

		add(new JScrollPane(Input));
		add(new JScrollPane(Expected));
		add(new JScrollPane(Output));
		add(new JScrollPane(Linkdowninput));
		setLayout(new GridLayout(4,1));
		

		 
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Data");
		// set the border
		setBorder(titled);
	}
 
 public synchronized void displaySend(CommObj obj) {
		String message = new String("MsgId: " + obj.getMsgID() + " " +
									"NodeType: " + obj.getNodeType() + " " +
									"FieldType: " + obj.getFieldType() + " " +
									"Data: " + obj.getData() + " " +
									"TimeSent: " + obj.getTimeSent() + " " +
									"TimeRec: " + obj.getTimeRec() + " " +
									"Priority: " + obj.getPriority() + " " +
									"Ack: " + obj.getAck() + " " +
									"SrcNode: " + obj.getSrcNode() + " " +
									"TargetNode: " + obj.getTargetNode() + "\n");
		
		Input.append(message);
	}
 
 public synchronized void displayExpected(CommObj obj) {
		String message = new String("MsgId: " + obj.getMsgID() + " " +
									"NodeType: " + obj.getNodeType() + " " +
									"FieldType: " + obj.getFieldType() + " " +
									"Data: " + obj.getData() + " " +
									"TimeSent: " + obj.getTimeSent() + " " +
									"TimeRec: " + obj.getTimeRec() + " " +
									"Priority: " + obj.getPriority() + " " +
									"Ack: " + obj.getAck() + " " +
									"SrcNode: " + obj.getSrcNode() + " " +
									"TargetNode: " + obj.getTargetNode() + "\n");
		
		Expected.append(message);
	}
 
 public synchronized void displayOutput(CommObj obj) {
		String message = new String("MsgId: " + obj.getMsgID() + " " +
									"NodeType: " + obj.getNodeType() + " " +
									"FieldType: " + obj.getFieldType() + " " +
									"Data: " + obj.getData() + " " +
									"TimeSent: " + obj.getTimeSent() + " " +
									"TimeRec: " + obj.getTimeRec() + " " +
									"Priority: " + obj.getPriority() + " " +
									"Ack: " + obj.getAck() + " " +
									"SrcNode: " + obj.getSrcNode() + " " +
									"TargetNode: " + obj.getTargetNode() + "\n");
		
		Output.append(message);
	}
 
 public synchronized void displayLinkDown(CommObj obj) {
		String message = new String("MsgId: " + obj.getMsgID() + " " +
									"NodeType: " + obj.getNodeType() + " " +
									"FieldType: " + obj.getFieldType() + " " +
									"Data: " + obj.getData() + " " +
									"TimeSent: " + obj.getTimeSent() + " " +
									"TimeRec: " + obj.getTimeRec() + " " +
									"Priority: " + obj.getPriority() + " " +
									"Ack: " + obj.getAck() + " " +
									"SrcNode: " + obj.getSrcNode() + " " +
									"TargetNode: " + obj.getTargetNode() + "\n");
		
		Linkdowninput.append(message);
	}

 
 
 
 
 
 

	public JTextArea getInput() {
		return Input;
	}

	public void setInput(JTextArea input) {
		Input = input;
	}

	public JTextArea getExpected() {
		return Expected;
	}

	public void setExpected(JTextArea expected) {
		Expected = expected;
	}

	public JTextArea getOutput() {
		return Output;
	}

	public void setOutput(JTextArea output) {
		Output = output;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}

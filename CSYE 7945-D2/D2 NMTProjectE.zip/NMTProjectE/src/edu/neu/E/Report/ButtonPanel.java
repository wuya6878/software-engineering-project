package edu.neu.E.Report;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import edu.neu.d1.data.CommObj;


public class ButtonPanel extends JPanel {
	private JComboBox<Integer> MegID;
	private ArrayList<CommObj> expected;
	private ArrayList<CommObj> output;
	private CommObj commObj;
	private CommObj commObjoutput;

	
	public ButtonPanel(final TableView tableView)
	{
/*		resultList = new ArrayList<String>();
		expectedData = new ArrayList<String>();W
		outputData = new ArrayList<String>();
		commObj = new CommObj();*/
		commObjoutput = new CommObj();
		MegID = new JComboBox();
		add(new JLabel("Message ID"));
		add(MegID);
		
		
		
		MegID.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent event)
			{
/*				commObj = searchData(MegID.getSelectedItem(), getExpected()).get(0);
				commObjoutput= searchData(MegID.getSelectedItem(),getOutput()).get(0);
				expectedData = readFile(expectedData, commObj);
				outputData = readFile(outputData, commObjoutput);*/
				commObj = searchData(expected,MegID.getSelectedItem().toString());
				commObjoutput = searchData(output,MegID.getSelectedItem().toString());
				tableView.Display(getCommObj(),getCommObjoutput(), compare(readData(commObj),readData(commObjoutput)));
			}
		});
	}
	

	
	public CommObj searchData(ArrayList<CommObj> dataList, String ID)
	{
		CommObj tempObj = new CommObj();
		for(CommObj commObj: dataList)
		{
			if(String.valueOf(commObj.getMsgID()).equals(ID))
			{
				tempObj =commObj;
			}
		}
		return tempObj;
	}
	
	public ArrayList<String> readData(CommObj commObj)
	{
		ArrayList<String> templist = new ArrayList<String>();
		templist.add(String.valueOf(commObj.getMsgID()));
		templist.add(String.valueOf(commObj.getSrcNode()));
		templist.add(String.valueOf(commObj.getTargetNode()));
		templist.add(String.valueOf(commObj.getAck()));
		templist.add(String.valueOf(commObj.getPriority()));
		templist.add(String.valueOf(commObj.getNodeType()));
		templist.add(String.valueOf(commObj.getFieldType()));
		templist.add(String.valueOf(commObj.getData()));
		return templist;
		
	}
	
	
	public ArrayList<String> compare(ArrayList<String> expect,ArrayList<String> output)
	{
		ArrayList<String> temple = new ArrayList<String>();
		for(int i = 0; i<expect.size(); i++)
		{
			if(String.valueOf(expect.get(i)).equals(String.valueOf(output.get(i))))
			{
				temple.add("true");
			}
			else
			{
				temple.add("false");
			}
		}
		return temple;
	}
	
/*	public ArrayList<CommObj> addData(ArrayList<CommObj> list)
	{
		ArrayList<CommObj> commObjlist = new ArrayList<CommObj>();
		for(CommObj commObj : list)
		{
			if(!commObjlist.contains(commObj.getMsgID()))
			{
				commObjlist.add(commObj);
			}
		}
		return commObjlist;
	}*/
	

	public JComboBox<Integer> getMegID() {
		return MegID;
	}

	public void setMegID(JComboBox<Integer> megID) {
		MegID = megID;
	}

	public ArrayList<CommObj> getExpected() {
		return expected;
	}

	public void setExpected(ArrayList<CommObj> expected) {
		this.expected = expected;
	}

	public ArrayList<CommObj> getOutput() {
		return output;
	}

	public void setOutput(ArrayList<CommObj> output) {
		this.output = output;
	}


	public CommObj getCommObj() {
		return commObj;
	}


	public void setCommObj(CommObj commObj) {
		this.commObj = commObj;
	}


	public CommObj getCommObjoutput() {
		return commObjoutput;
	}


	public void setCommObjoutput(CommObj commObjoutput) {
		this.commObjoutput = commObjoutput;
	}
	
	
}

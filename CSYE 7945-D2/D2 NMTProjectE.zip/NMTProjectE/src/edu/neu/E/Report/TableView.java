package edu.neu.E.Report;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

import edu.neu.d1.data.CommObj;

public class TableView extends JPanel {
	 private DefaultTableModel model;
	 private DefaultTableModel rowheader;
	 private JTable table;
	 public TableView()
	 {
		table = new JTable(model); 
		JTableHeader header = table.getTableHeader();
		header.setBackground(Color.yellow);
		

		
		
		JScrollPane pane = new JScrollPane(table);
		add(pane);
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Result");
			// set the border
		 setBorder(titled);
	 }
	 
	 public void Display(CommObj commObj, CommObj output,ArrayList<String> result)
	 {
				String data[][] = 
			  {{String.valueOf(commObj.getMsgID()),
				String.valueOf(commObj.getSrcNode()),
				String.valueOf(commObj.getTargetNode()),
				String.valueOf(commObj.getAck()),		
				String.valueOf(commObj.getPriority()),
				String.valueOf(commObj.getNodeType()),
				String.valueOf(commObj.getFieldType()),
				String.valueOf(commObj.getData())
				},
				{String.valueOf(commObj.getMsgID()),
					String.valueOf(output.getSrcNode()),
					String.valueOf(output.getTargetNode()),
					String.valueOf(output.getAck()),		
					String.valueOf(output.getPriority()),
					String.valueOf(commObj.getNodeType()),
					String.valueOf(output.getFieldType()),
					String.valueOf(output.getData())
					},
					{result.get(0),
						result.get(1),
						result.get(2),
						result.get(3),		
						result.get(4),
						result.get(5),
						result.get(6),
						result.get(7)
						}};
				String col[] = {"MsgID","SrcNode","TargetNode","Ack","Priority", "NodeType", "FieldType","Data"};
				model = new DefaultTableModel(data,col);
				table.setModel(model);
	 }
	 
}

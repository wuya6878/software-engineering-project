package edu.neu.E.Report;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.JFrame;

import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;

public class Report extends Node{
	
	private ArrayList<CommObj> expected;
	private ArrayList<CommObj> output;
	private ButtonPanel buttonPanel;
	private TableView tableView;
	
	public Report()
	{
		
		super("Report");
		revalidate();
		repaint();
		tableView = new TableView();
		buttonPanel = new ButtonPanel(tableView);
		add(buttonPanel, BorderLayout.WEST);
		add(tableView, BorderLayout.EAST);

		pack();
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	public ArrayList<CommObj> getExpected() {
		return expected;
	}

	public void setExpected(ArrayList<CommObj> expected) {
		this.expected = expected;
	}

	public ArrayList<CommObj> getOutput() {
		return output;
	}

	public void setOutput(ArrayList<CommObj> output) {
		this.output = output;
	}

	public ButtonPanel getButtonPanel() {
		return buttonPanel;
	}

	public void setButtonPanel(ButtonPanel buttonPanel) {
		this.buttonPanel = buttonPanel;
	}
}

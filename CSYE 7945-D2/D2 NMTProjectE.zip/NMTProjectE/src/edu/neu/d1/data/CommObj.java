package edu.neu.d1.data;

/**
 * 
 * @author hermida
 *
 */
public class CommObj implements Cloneable {

    public CommObj (int MsgID,
                    String data,
                    boolean ack){
        setAck(ack);
        setData(data);
        this.MsgID = MsgID;

    }
    
    public CommObj(){}

    private int NodeType;
    private String FieldType;
    private Object Data;
    private long TimeSent;
    private long TimeRec;
    private int Priority;

    private int MsgID;
    private Boolean Ack;
    private int TargetNode;
    private int SrcNode;

    public int getNodeType() {
        return NodeType;
    }
    public void setNodeType(int n) {
        NodeType = n;
    }
    public String getFieldType() {
        return FieldType;
    }
    public void setFieldType(String fieldType) {
        FieldType = fieldType;
    }
    public Object getData() {
        return Data;
    }
    public void setData(Object data) {
        Data = data;
    }


    public long getTimeSent() {
        return TimeSent;
    }
    public void setTimeSent(long timeSent) {
        TimeSent = timeSent;
    }
    public long getTimeRec() {
        return TimeRec;
    }
    public void setTimeRec(long timeRec) {
        TimeRec = timeRec;
    }
    public int getMsgID() {
        return MsgID;
    }
    public void setMsgID(int msgID) {
        MsgID = msgID;
    }
    public Boolean getAck() {
        return Ack;
    }
    public void setAck(Boolean ack) {
        Ack = ack;
    }
    public int getTargetNode() {
        return TargetNode;
    }
    public void setTargetNode(int targetNode) {
        TargetNode = targetNode;
    }
    public int getSrcNode() {
        return SrcNode;
    }
    public void setSrcNode(int srcNode) {
        SrcNode = srcNode;
    }

    public int getPriority() {
        return Priority;
    }
    public void setPriority(int priority) {
        Priority = priority;
    }
        
    public Object clone() {
    	try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return this.backupClone();
    }
    
	/**
	 * In case the clone() doesn't work
	 * @param origObj
	 * @return
	 */
	private CommObj backupClone() {
		
		CommObj obj = new CommObj();
		
		
		obj.setMsgID(getMsgID());
		obj.setNodeType(getNodeType());
		obj.setFieldType(getFieldType());
		obj.setData(getData());
		obj.setTimeSent(getTimeSent());
		obj.setTimeRec(getTimeRec());
		obj.setPriority(getPriority());
		obj.setAck(getAck());
		obj.setTargetNode(getTargetNode());
		obj.setSrcNode(getSrcNode());

		return obj;
	}
}

package edu.neu.d1.driver;

import java.awt.EventQueue;

import edu.neu.E.DataGenerate.GenerateData;

/**
 * 
 * @author hermida
 *
 */
public class EvaluationToolDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				GenerateData frame = new GenerateData();
				frame.pack();
				frame.setVisible(true);
			}
		});
	}
}

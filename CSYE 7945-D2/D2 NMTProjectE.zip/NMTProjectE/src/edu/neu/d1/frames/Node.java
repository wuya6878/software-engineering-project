package edu.neu.d1.frames;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

/**
 * 
 * @author hermida
 *
 */
public class Node extends JFrame {
	public static int latency = 0;
	private String type;
	private int nodeId;
	
	public Node(String type) {
		this.type = type;
		constructFrame();
	}
	
	public Node(String type, int nodeId) {
		this.type = type;
		this.nodeId = nodeId;
		
		constructFrame();
	}
	
	/**
	 * Construct the structure of the frame.
	 */
	private void constructFrame() {
		
		// get the interface for the native windowing system.
		Toolkit kit = Toolkit.getDefaultToolkit();
		
		// get the screen size from the toolkit object
		Dimension screenSize = kit.getScreenSize();
		
		// get the width and height of the screen
		int screenWidth = screenSize.width;
		int screenHeight = screenSize.height;
		
		// Resizes this component so that it has width and height.
		setSize(300, 200);
				
		if(nodeId > 0) {
			// set the title of the frame
			setTitle(type + " " + nodeId);
		} else {
			setTitle(type);
		}
		// set the location of the frame according to the platform
		setLocationByPlatform(true);
		
		// set the default close operation
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

	}

}

package edu.neu.d1.frames;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;

import edu.neu.d1.information.InfoNetworkLocalObj;
import edu.neu.d1.information.InfoNetworkPanel;
import edu.neu.d1.social.SocialNetworkLocalObj;
import edu.neu.d1.social.SocialNetworkPanel;

public class SocialAndInfoPanel extends JPanel {
	
	private InfoNetworkPanel inp;
	private SocialNetworkPanel snp;
	private SocialNetworkLocalObj snlo;
	private InfoNetworkLocalObj inlo;
	
	
	public SocialAndInfoPanel(SocialNetworkLocalObj snlo, InfoNetworkLocalObj inlo) {
		this.snlo = snlo;
		this.inlo = inlo;
		
		inp = new InfoNetworkPanel(this.inlo);
		snp = new SocialNetworkPanel(this.snlo);
		
		setLayout(new GridLayout(1,2));
		add(snp);
		add(inp);
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Local Data");
		
		// set the border
		setBorder(titled);
		
		new Thread(inp).start();
		new Thread(snp).start();
		
	}
}

package edu.neu.d1.social;

import java.util.ArrayList;

public class SocialNetworkLocalObj {
	private String name;
	private String address;
	private String dateOfBirth;
	private String phoneNumber;
	private ArrayList<Integer> friendList;
	private String occupation;
	private String statusBlurb;
	
	public SocialNetworkLocalObj() {
		name = "";
		address = "";
		dateOfBirth = "";
		phoneNumber = "";
		friendList = new ArrayList<Integer>();
		occupation = "";
		statusBlurb = "";
		
	}
	public void setName(String n) {
		name = n;
	}
	
	public String getName() {
		return name;		
	}
	
	public void setAddress(String a) {
		address = a;
	}
	
	public String getAddress() {
		return address;		
	}	
	
	public void setDateOfBirth(String dob) {
		dateOfBirth = dob;
	}
	
	public String getDateOfBirth() {
		return dateOfBirth;		
	}
	
	public void setPhoneNumber(String n) {
		phoneNumber = n;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;		
	}
	
	@SuppressWarnings("unchecked")
	public void setFriendList(ArrayList <Integer> list) {
		friendList = (ArrayList<Integer>) list.clone();
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList <Integer> getFriendList() {
		return (ArrayList<Integer>) friendList.clone();		
	}
	
	public void setOccupation(String occ) {
		occupation = occ;
	}
	
	public String getOccupation() {
		return occupation;		
	}
	
	public void setStatusBlurb(String s) {
		statusBlurb = s;
	}
	
	public String getStatusBlurb() {
		return statusBlurb;		
	}
}

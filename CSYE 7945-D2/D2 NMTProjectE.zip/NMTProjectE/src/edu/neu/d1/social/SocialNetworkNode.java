package edu.neu.d1.social;

import java.awt.GridLayout;
import java.util.ArrayList;

import edu.neu.d1.communication.CommunicationNetworkNode;
import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;

public class SocialNetworkNode extends Node{
	SocialNetworkLocalObj localObj;
	private CommunicationNetworkNode cnn;
	private SocialNetworkPanel panel; 
	
	public SocialNetworkNode(final CommunicationNetworkNode cnn) {
		super("Social Network", cnn.getNodeId());
		this.cnn = cnn;
		localObj = new SocialNetworkLocalObj();
		cnn.setMySocialData(this);
	}
	
	@SuppressWarnings("unchecked")
	public void setLocalData (CommObj cObj) {
		String field = cObj.getFieldType();
		Object data = cObj.getData();
		
		// Ignore case during comparison
		if (field.equalsIgnoreCase("name")) {
			localObj.setName((String) data);
		}
		else if (field.equalsIgnoreCase("address")) {
			localObj.setAddress((String) data);
		}
		else if (field.equalsIgnoreCase("dateofbirth")) {
			localObj.setDateOfBirth((String) data);
		}
		else if (field.equalsIgnoreCase("phonenumber")) {
			localObj.setPhoneNumber((String) data);
		}
		else if (field.equalsIgnoreCase("friendlist")) {
			localObj.setFriendList((ArrayList <Integer>) data);
		}
		else if (field.equalsIgnoreCase("occupation")) {
			localObj.setOccupation((String) data);
		}
		else if (field.equalsIgnoreCase("statusblurb")) {
			localObj.setStatusBlurb((String) data);
		}
	
	}
	
	// For future implementations
	public SocialNetworkLocalObj getLocalData() {
		return localObj;
	}
}

package edu.neu.d1.social;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class SocialNetworkPanel extends JPanel implements Runnable{
	
	private JTextArea textArea;
	private SocialNetworkLocalObj snlo;
	
	public SocialNetworkPanel(SocialNetworkLocalObj snlo) {
		this.snlo = snlo;
		textArea = new JTextArea();
	
		setLayout(new GridLayout(1,1));
		add(textArea);
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Social Network");
		
		// set the border
		setBorder(titled);
	}

	@Override
	public void run() {
		while(true) {
			try {
				Thread.sleep(1000);
				display();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	private synchronized void display() {
		// clear the text
		textArea.setText("");
		
		textArea.append("Name:\t" + snlo.getName() + "\n");
		textArea.append("Address:\t" + snlo.getAddress() + "\n");
		textArea.append("DOB:\t" + snlo.getDateOfBirth() + "\n");
		textArea.append("Phone #:\t" + snlo.getPhoneNumber() + "\n");
		
		String friendList = new String("");
		for(int i = 0; i < snlo.getFriendList().size(); i++) {
			friendList = friendList.concat(snlo.getFriendList().get(i).toString() + " ");
		}
		
		textArea.append("Friend list:\t" + friendList + "\n");
		textArea.append("Occupation:\t" + snlo.getOccupation() + "\n");
		textArea.append("StatusBlurb:\t" + snlo.getStatusBlurb() + "\n");
	}
}

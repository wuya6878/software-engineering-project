package edu.neu.d1.communication;

import edu.neu.d1.data.CommObj;

/**
 * 
 * @author hermida
 *
 */
public interface CommunicationInterface {
	public void receiveData(CommObj commObj);
}

package edu.neu.d1.communication;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.GridLayout;


import edu.neu.E.DataGenerate.EInterface;
import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;
import edu.neu.d1.frames.SocialAndInfoPanel;
import edu.neu.d1.information.InfoNetworkNode;
import edu.neu.d1.nmt.NMTNode;
import edu.neu.d1.nmt.NMTPanel;
import edu.neu.d1.social.SocialNetworkNode;

/**
 * 
 * @author hermida
 *
 */
public class CommunicationNetworkNode extends Node implements CommunicationInterface {

	private static final long serialVersionUID = 1L;
	private final CommunicationNetworkNode cnn;
	public int NodeId;
	private EInterface MyOutputNode;
	private NMTNode MyNMT;
	private CommNetworNodeDisplayNetworkTraffic networkTraffic;
	public SocialNetworkNode MySocialData;
	public InfoNetworkNode MyInfoData;
	private InfoNetworkNode inn;
	private SocialAndInfoPanel sip;
	private NMTPanel nmtPanel;

	/**
	 * Constructor
	 * @param myOutputNode Evaluation Tool's Interface
	 * @param nodeId Uniquely identify a Communication Network Node
	 * @throws InterruptedException 
	 */
	public CommunicationNetworkNode(int NodeId, EInterface myOutputNode) {
		super("CommunicationNetworkNode",  NodeId);
		cnn = this;
		this.NodeId = NodeId;
		//this.setBackground(Color.GREEN);
		
		this.MyOutputNode = myOutputNode;
		networkTraffic = new CommNetworNodeDisplayNetworkTraffic();
		MyNMT = new NMTNode(cnn);
		MySocialData = new SocialNetworkNode(cnn);	
		MyInfoData = new InfoNetworkNode(cnn);
		sip = new SocialAndInfoPanel(MySocialData.getLocalData(), MyInfoData.getLocalData());
		nmtPanel = new NMTPanel(MyNMT);
		MyNMT.networkTraffic = nmtPanel.getNmtDisplayNetworkTraffic();
		
/*		EventQueue.invokeLater(new Runnable() {
			public void run() {
				// Create the NMT Node
				MyNMT = new NMTNode(cnn);				

			}
		});
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				// Create the NMT Node
				MySocialData = new SocialNetworkNode(cnn);			

			}
		});
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				// Create the NMT Node
				MyInfoData = new InfoNetworkNode(cnn);				

			}
		});
		*/
		
		// add the panels
		setLayout(new GridLayout(3,1));
		add(sip);
		add(nmtPanel);
		add(networkTraffic);
		
		pack();
		
		// TO DO: SocialNetworkNode, and InformationNetworkNode
		
	}
	
	/**
	 * Get the Communication Network Node's NodeId
	 * @return
	 */
	public int getNodeId() {
		return NodeId;
	}
	
	@Override
	public void receiveData(CommObj commObj) {
		networkTraffic.getReceiving().append(getString(commObj));
		CreateWorker(commObj);
	}
	
	/**
	 * Spawn off a worker thread.
	 */
	public void CreateWorker(CommObj commObj) {
		new WorkerThread(this, commObj).start();
	}
	/**
	 * Get the OutputNode
	 * @return EInterface
	 */
	public EInterface getMyOutputNode() {
		return MyOutputNode;
	}
	
	/**
	 * Send all CommObjs to NMT
	 * @param obj
	 */
	public synchronized void moveToNMT(CommObj obj) {
		networkTraffic.getSending().append(getString(obj));
		MyNMT.input(obj);
	}
	
	public NMTNode getMyNMT() {
		return MyNMT;
	}

	public void setMyNMT(NMTNode myNMT) {
		MyNMT = myNMT;
	}

	public SocialNetworkNode getMySocialData() {
		return MySocialData;
	}

	public void setMySocialData(SocialNetworkNode mySocialData) {
		MySocialData = mySocialData;
	}

	public InfoNetworkNode getMyInfoData() {
		return MyInfoData;
	}

	public void setMyInfoData(InfoNetworkNode myInfoData) {
		MyInfoData = myInfoData;
	}
	
	
	/**
	 * Get the string representation of the CommObj
	 * @param obj
	 * @return String
	 */
	public synchronized String getString(CommObj obj) {
		return (new String("MsgId: " + obj.getMsgID() + " " +
				"NodeType: " + obj.getNodeType() + " " +
				"FieldType: " + obj.getFieldType() + " " +
				"Data: " + obj.getData() + " " +
				"TimeSent: " + obj.getTimeSent() + " " +
				"TimeRec: " + obj.getTimeRec() + " " +
				"Priority: " + obj.getPriority() + " " +
				"Ack: " + obj.getAck() + " " +
				"SrcNode: " + obj.getSrcNode() +  " " +
				"TargetNode: " + obj.getTargetNode() + "\n"));
	}
	/**
	 * WorkerThread is spawned off each time the CommunicationNetworkNode
	 * receives data via the receiveData() CommunicationInterface.
	 * @author hermida
	 *
	 */
	private class WorkerThread extends Thread{
		
		private CommunicationNetworkNode commNode;
		private CommObj commObj;
		
		/**
		 * Constructor
		 * @param commNode associated communication network node
		 * @param commObj message to move to NMT
		 */
		public WorkerThread(CommunicationNetworkNode commNode, CommObj commObj) {
			this.commNode = commNode;
			this.commObj = commObj;
		}
		
		/**
		 * Thread's entry point
		 */
		public void run() {
			try {
				Thread.sleep(Node.latency);
				process();
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			
		}
		
		/**
		 * Move to the NMT
		 */
		private void process() {
			commNode.moveToNMT(commObj);
		}
		
	}
}

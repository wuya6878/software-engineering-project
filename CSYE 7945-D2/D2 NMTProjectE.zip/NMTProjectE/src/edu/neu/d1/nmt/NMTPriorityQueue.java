package edu.neu.d1.nmt;

import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import edu.neu.d1.data.CommObj;

@SuppressWarnings("rawtypes")
public class NMTPriorityQueue extends JPanel {
	private static final long serialVersionUID = 1L;
	
	private JTextArea priorityQueue;
	private NMTNode nmt;
	
	public NMTPriorityQueue(NMTNode nmt) {
		this.nmt = nmt;
		
		priorityQueue = new JTextArea(10,10);
		
		setLayout(new GridLayout(1,1));
		add(new JScrollPane(priorityQueue));
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Priority Queue");
		
		// set the border
		setBorder(titled);
		
		// create a display worker
		new DisplayWorker(nmt).start();
	}
	
	public JTextArea getPriorityQueue() {
		return priorityQueue;
	}
	
	public NMTNode getNmt() {
		return nmt;
	}
	
	public void setNmt(NMTNode nmt) {
		this.nmt = nmt; 
	}
	
	private class DisplayWorker extends Thread {
		private NMTNode nmtNode;
		
		public DisplayWorker(final NMTNode nmtNode) {
			this.nmtNode = nmtNode;
		}
		
		public void run() {
			while(true) {
				try {
					Thread.sleep(1000);
					display();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
		public synchronized void display(){
			// clear the data
			priorityQueue.setText("");
	
			for(int i = 0; i < nmtNode.getCommObjectsList().size(); i++) {
				priorityQueue.append(getString(nmtNode.getCommObjectsList().get(i)) + "\n");
				
			}
		}
		
		/**
		 * Get the string representation of the CommObj
		 * @param obj
		 * @return String
		 */
		private String getString(CommObj obj) {
			return (new String("MsgId: " + obj.getMsgID() + " " +
					"NodeType: " + obj.getNodeType() + " " +
					"FieldType: " + obj.getFieldType() + " " +
					"Data: " + obj.getData() + " " +
					"TimeSent: " + obj.getTimeSent() + " " +
					"TimeRec: " + obj.getTimeRec() + " " +
					"Priority: " + obj.getPriority() + " " +
					"Ack: " + obj.getAck() + " " +
					"SrcNode: " + obj.getSrcNode() +  " " +
					"TargetNode: " + obj.getTargetNode() + "\n"));
		}
		
	}
}

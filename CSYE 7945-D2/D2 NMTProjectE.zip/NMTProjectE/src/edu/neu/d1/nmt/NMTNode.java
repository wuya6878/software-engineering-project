package edu.neu.d1.nmt;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.*;

import javax.swing.JPanel;

import edu.neu.d1.communication.CommunicationNetworkNode;
import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;


/**
 * Last edited by: Peter Goransson
 * Date: 4/8/2012
 */

public class NMTNode extends Node {
	
	private NMTPriorityQueue priorityQueue;
    public final CommunicationNetworkNode MyCommNode;
    public NMTDisplayNetworkTraffic networkTraffic;
    private ArrayList<CommObj> CommObjectsList = new ArrayList<CommObj>();   
    public long TIMER_PERIOD = 3 * 1000; // 3 second period
       
	public NMTNode (final CommunicationNetworkNode c){
    	super("NMTNode",  c.NodeId);
    	// set handle to MyCommNode
    	this.MyCommNode = c;
    	
    	// Start the timer...
		new Timer().schedule(new Ticker(),0, TIMER_PERIOD);
    }
    
    public void input(CommObj cObj) {
    	networkTraffic.getReceiving().append(getString(cObj));
    	// Check if this is an ack
    	if(cObj.getAck() == true) {
    		deleteCommObj(cObj);
    	}
    	else {
        	// Check if this is the source of the CommObj
        	if (cObj.getSrcNode() == MyCommNode.NodeId) {   
        		updateLocalNodes(cObj);
        		storeCommObj(cObj);	
        	}
        	else {
        		// this is the target, send ack back
        		sendAck(cObj);
        	}     		
    	}    	   	
    }        
    
    /*
     * void updateLocalNodes(CommObj)
     * Determines which local node to update and calls setLocalData on that obj
     */    
    private void updateLocalNodes(CommObj cObj) {
    	switch (cObj.getNodeType()) {
    	 	case 0: // Social
    	 		MyCommNode.MySocialData.setLocalData(cObj);
    	 	break;
    	 	case 1: // Info
    	 		MyCommNode.MyInfoData.setLocalData(cObj);
    	 	break;
    	 	default: 
    	 		// IGNORE
    	 		// Communication message does not get stored
    	
    	}

    }
    
    /*
     * void storeCommObj(CommObj)
     * Add a CommObj to the list
     */
    private void storeCommObj(CommObj cObj) {
    	CommObj clone = (CommObj) cObj.clone();
    	CommObjectsList.add(clone);
    }
    
    /*
     * void deleteCommObj(CommObj)
     * Deletes a CommObj from CommObjectsList
     *  based on its MsgID
     */    
    private void deleteCommObj(CommObj cObj) {
    	for (int i = 0; i < CommObjectsList.size(); i++) {
    		// Compare msgID to delete
    		if (CommObjectsList.get(i).getMsgID() == cObj.getMsgID()) {
    			CommObjectsList.remove(i);
    			break; // found it, break loop
    		}
    	}
    	
    }
    
    /*
     * void sendAck(CommObj)
     * Sends an ack message back to source 
     */
    private void sendAck(CommObj cObj) {
    	CommObj clone = (CommObj) cObj.clone(); 
    	
    	// Set ack to true
    	clone.setAck(true);
    	// Swap source and target    	
    	int source = clone.getSrcNode();
    	int target = clone.getTargetNode();
    	clone.setSrcNode(target);
    	clone.setTargetNode(source);
    	
    	// send to E tool
    	sendCommObj(clone);
    }
    
    /*
     * void sendCommObj(CommObj)
     * Just a helper method to send a CommObj to E tool
     */    
    private synchronized void sendCommObj(CommObj cObj) {
    	networkTraffic.getSending().append(getString(cObj));
    	CommObj clone = (CommObj) cObj.clone();
    	MyCommNode.getMyOutputNode().ReceiveData(clone);
    }
    
    /*
     * void sortByPriority()
     * will sort CommObjectsList based on priority level 
     */
    private void sortByPriority() {
        
        if (CommObjectsList.size() == 1){
            return;            
        }        
        else {            
        	Collections.sort(CommObjectsList, COMPARE_COMMOBJ);            
        }
        
    }    
    
	private synchronized void sendCommObjectList() {
		for (int i=0; i< CommObjectsList.size(); i++) {
			sendCommObj(CommObjectsList.get(i));
		}
	}
    
    private static Comparator<CommObj> COMPARE_COMMOBJ = new Comparator<CommObj>() {
	    // This is where the sorting happens.
	        public int compare(CommObj c1, CommObj c2)
	        {	        	
	        	if (c1.getPriority() == c2.getPriority()) {
	        		if (c1.getTimeSent() > c2.getTimeSent()) {
	        			return 1;
	        		}
	        		return -1;
	        	}
	        	return c1.getPriority() - c2.getPriority();
	        }
	};
	
	
    /*
     * Debug method for printing listOfCommObjects
     * This printout can be modified/customized
     */
	public void printCommObjects() {
		Iterator<CommObj> it = CommObjectsList.iterator();
		while (it.hasNext()) {
			CommObj c = (CommObj) it.next();
			System.out.println("msg id:" + 
			                    c.getMsgID() + ", " +
					            "priority:" + c.getPriority() +", " +
			                    "time sent:" + c.getTimeSent());
		}
	}
	
	private class Ticker extends TimerTask {
		/*
		 * void run()
		 * When the timer executes, this code is run.
		 * 1. Prioritizes the List.
	     * 2. Sends every object in the list.
	     * 
	     * This is called every n seconds
		 */
		public void run() {
			// 1. prioritize the list
			sortByPriority(); 
			
			// 2. Send every object in the list.
			sendCommObjectList();
		}
		
	}

	/**
	 * Return the List
	 * @return
	 */
    public ArrayList<CommObj> getCommObjectsList() {
		return CommObjectsList;
	}
    
	/**
	 * Get the string representation of the CommObj
	 * @param obj
	 * @return String
	 */
	public synchronized String getString(CommObj obj) {
		return (new String("MsgId: " + obj.getMsgID() + " " +
				"NodeType: " + obj.getNodeType() + " " +
				"FieldType: " + obj.getFieldType() + " " +
				"Data: " + obj.getData() + " " +
				"TimeSent: " + obj.getTimeSent() + " " +
				"TimeRec: " + obj.getTimeRec() + " " +
				"Priority: " + obj.getPriority() + " " +
				"Ack: " + obj.getAck() + " " +
				"SrcNode: " + obj.getSrcNode() +  " " +
				"TargetNode: " + obj.getTargetNode() + "\n"));
	}
}

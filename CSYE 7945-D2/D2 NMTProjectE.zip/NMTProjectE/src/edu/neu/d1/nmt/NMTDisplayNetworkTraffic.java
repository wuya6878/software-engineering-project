package edu.neu.d1.nmt;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

/**
 * 
 * @author hermida
 *
 */
public class NMTDisplayNetworkTraffic extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextArea sending;
	private JTextArea receiving;
	
	public NMTDisplayNetworkTraffic() {
		sending = new JTextArea("Sending:\n",10,20);
		receiving = new JTextArea("Receiving:\n",10,20);
		
		setLayout(new GridLayout(2,1,2,4));
		add(new JScrollPane(sending));
		add(new JScrollPane(receiving));
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "NMT Traffic");
		
		// set the border
		setBorder(titled);
	}

	public JTextArea getSending() {
		return sending;
	}

	public JTextArea getReceiving() {
		return receiving;
	}
}

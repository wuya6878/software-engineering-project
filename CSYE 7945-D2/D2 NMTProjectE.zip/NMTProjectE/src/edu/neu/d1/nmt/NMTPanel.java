package edu.neu.d1.nmt;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class NMTPanel extends JPanel {
	
	private NMTNode nmt;
	private NMTDisplayNetworkTraffic nmtDisplayNetworkTraffic;
	private NMTPriorityQueue nmtPriorityQueue;
	
	public NMTPanel(NMTNode nmt) {
		this.nmt = nmt;
		
		nmtDisplayNetworkTraffic = new NMTDisplayNetworkTraffic();
		nmtPriorityQueue = new NMTPriorityQueue(nmt);
		
		setLayout(new GridLayout(1,2));
		add(nmtDisplayNetworkTraffic);
		add(nmtPriorityQueue);
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "NMT");
		
		// set the border
		setBorder(titled);
		
	}

	public NMTDisplayNetworkTraffic getNmtDisplayNetworkTraffic() {
		return nmtDisplayNetworkTraffic;
	}

	public void setNmtDisplayNetworkTraffic(
			NMTDisplayNetworkTraffic nmtDisplayNetworkTraffic) {
		this.nmtDisplayNetworkTraffic = nmtDisplayNetworkTraffic;
	}

	public NMTPriorityQueue getNmtPriorityQueue() {
		return nmtPriorityQueue;
	}

	public void setNmtPriorityQueue(NMTPriorityQueue nmtPriorityQueue) {
		this.nmtPriorityQueue = nmtPriorityQueue;
	}
	
	
}

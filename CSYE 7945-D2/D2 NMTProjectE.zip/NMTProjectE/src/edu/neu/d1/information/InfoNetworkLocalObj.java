package edu.neu.d1.information;

import java.util.ArrayList;

public class InfoNetworkLocalObj {
	private String medicalInfo;
	private String GPSLocation;
	
	@SuppressWarnings("unused")
	private ArrayList <String> ICEContacts;
	
	public InfoNetworkLocalObj() {
		medicalInfo = "";
		GPSLocation = "";
		ICEContacts = new ArrayList<String>();
	}
	
	public void setMedicalInfo(String m) {
		medicalInfo = m;
	}
	
	public String getMedicalInfo() {
		return medicalInfo;
	}
	
	public void setGPSLocation(String g) {
		GPSLocation = g;
	}
	
	public String getGPSLocation() {
		return GPSLocation;
	}	
	
	@SuppressWarnings("unchecked")
	public void setICEContacts(ArrayList <String> list) {
		ICEContacts = (ArrayList<String>) list.clone();
	}
	
	public ArrayList<String> getICEContacts() {
		return ICEContacts;
	}
}

package edu.neu.d1.information;

import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import edu.neu.d1.social.SocialNetworkLocalObj;

public class InfoNetworkPanel extends JPanel implements Runnable {
	private JTextArea textArea;
	private InfoNetworkLocalObj inlo;
	
	public InfoNetworkPanel(InfoNetworkLocalObj inlo) {
		this.inlo = inlo;
		textArea = new JTextArea();
	
		setLayout(new GridLayout(1,1));
		add(textArea);
		
		// create a border
		Border etched = BorderFactory.createEtchedBorder();
		Border titled = BorderFactory.createTitledBorder(etched, "Info Network");
		
		// set the border
		setBorder(titled);
	}

	@Override
	public void run() {
		while(true) {
			try {
				Thread.sleep(1000);
				display();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	private synchronized void display() {
		// clear the text
		textArea.setText("");
		
		textArea.append("GPS:\t" + inlo.getGPSLocation() + "\n");
		textArea.append("Medical:\t" + inlo.getMedicalInfo() + "\n");
		
		String contacts = new String("");
		for(int i = 0; i < inlo.getICEContacts().size(); i++) {
			contacts = contacts.concat(inlo.getICEContacts().get(i).toString() + " ");
		}
		textArea.append("ICEContacts:\t" + contacts);
	}
}

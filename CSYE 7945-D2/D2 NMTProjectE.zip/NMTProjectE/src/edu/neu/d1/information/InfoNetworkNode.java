package edu.neu.d1.information;

import edu.neu.d1.communication.CommunicationNetworkNode;
import edu.neu.d1.data.CommObj;
import edu.neu.d1.frames.Node;

import java.awt.GridLayout;
import java.util.ArrayList;

public class InfoNetworkNode extends Node{
	InfoNetworkLocalObj localObj;
	private CommunicationNetworkNode cnn;
	private InfoNetworkPanel panel;
	
	public InfoNetworkNode(final CommunicationNetworkNode cnn) {
		super("Information Network", cnn.getNodeId());
		this.cnn = cnn;
		cnn.setMyInfoData(this);
		localObj = new InfoNetworkLocalObj();
	}
	
	@SuppressWarnings("unchecked")
	public void setLocalData (CommObj cObj) {
		String field = cObj.getFieldType();
		Object data = cObj.getData();
		
		// Ignore case during comparison
		if (field.equalsIgnoreCase("medicalinfo")) {
			localObj.setMedicalInfo((String) data);
		}
		else if (field.equalsIgnoreCase("gpslocation")) {
			localObj.setGPSLocation((String) data);
		}
		else if (field.equalsIgnoreCase("icecontacts")) {
			localObj.setICEContacts((ArrayList <String>) data);
		}
	}
	
	// For future implementations
	public InfoNetworkLocalObj getLocalData() {
		return localObj;
	}
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.d2.social;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.table.DefaultTableModel;



import edu.neu.d1.data.CommObj;
import edu.neu.d2.bean.D2CommObj;
import edu.neu.d2.ui.NMTCommunicationJPanel;
import edu.neu.d2.util.DBUtil;
/**
 * SocialNetworkNode class
 * @author Salim
 */
public class SocialNetworkNode {
   
	/**
	 *  all received CommObj list added for UI
	 */
    private List<CommObj> socialDataList;
    /**
     * all sent CommObj list added for UI
     */
    private List<CommObj> sentSocialDataList;
    
    /**
     * added for UI
     */
    private NMTCommunicationJPanel jPanel;
    DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss.SSS");
    Calendar calendar = Calendar.getInstance();
    
    
    /**
     * constructor
     */
    public SocialNetworkNode()
    {
        this.socialDataList = new ArrayList<CommObj>();
        this.sentSocialDataList = new ArrayList<CommObj>();
    }

    /**
     * getter for sent commObj list
     * @return
     */
    public List<CommObj> getSentSocialDataList() {
        return sentSocialDataList;
    }

    /**
     * getter for recieved commObj list
     * @return
     */
    public List<CommObj> getSocialDataList() {
        return socialDataList;
    }
    /**
     * insert all received data into list
     * and display it on UI
     * @param commObj
     */
    public void insertData(CommObj commObj)
    {
        this.socialDataList.add(commObj);
        addRecivedRowToJTable(commObj);
        
        addToSocialJTable(commObj);
        
        //new commObj for Db
        D2CommObj dbCommObj = D2CommObj.newD2CommObj(commObj);
        dbCommObj.setAck(true);
        DBUtil.insertCommObj(dbCommObj, dbCommObj.getTargetNode());
    }
    /**
     * insert all send data into list
     * and display it on UI
     * @param commObj
     */
    public void insertSentData(CommObj commObj)
    {
        this.sentSocialDataList.add(commObj);
        addSentRowToJTable(commObj);
    }
    
    /**
     * added for UI
     * @param jPanel
     */
    public void setJPanel(NMTCommunicationJPanel jPanel)
    {
        this.jPanel = jPanel;
    }
    
    /**
     * added for UI
     * @param commObj
     */
    public void addRecivedRowToJTable(CommObj commObj)
    {
        Object[] row = new Object[6];
         row[0] = commObj.getMsgID();
         row[1] = commObj.getSrcNode();
         row[2] = commObj.getTargetNode();
         row[3]= commObj.getNodeType()==0?"Social" : "Information";
         row[4] = commObj.getPriority();
         calendar.setTimeInMillis(commObj.getTimeRec());
         row[5] = formatter.format(calendar.getTime());
         ((DefaultTableModel) this.jPanel.receivedPacketJTable.getModel()).addRow(row);
    }
    
    
    /**
     * added for UI
     * @param commObj
     */
    public void addSentRowToJTable(CommObj commObj)
    {
        Object[] row = new Object[6];
         row[0] = commObj.getMsgID();
         row[1] = commObj.getSrcNode();
         row[2] = commObj.getTargetNode();
         row[3]= commObj.getNodeType()==0?"Social" : "Information";
         row[4] = commObj.getPriority();
         calendar.setTimeInMillis(commObj.getTimeSent());
         row[5] = formatter.format(calendar.getTime());
         ((DefaultTableModel) this.jPanel.sentPacketsJTable.getModel()).addRow(row);
    }
    
    /**
     * added for UI
     * @param commObj
     */
    public void addToSocialJTable(CommObj commObj)
    {
         Object[] row = new Object[4];
         row[0] = commObj.getSrcNode();
         row[1] = commObj.getTargetNode();
         row[2] = commObj.getData().toString();
         calendar.setTimeInMillis(commObj.getTimeRec());
         row[3] = formatter.format(calendar.getTime());
         ((DefaultTableModel) this.jPanel.socialJTable.getModel()).addRow(row);
    }

}

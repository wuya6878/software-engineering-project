/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.d2.communication.commService;

import edu.neu.d2.communication.NMTData;



/**
 *
 * @author Salim
 * Resend Thread Class
 */
public class ResendDataThread implements Runnable{

    private NMTData nmtData;
    
    /**
     * 
     * @param nmtData
     * Constructor
     * 
     */
    public ResendDataThread(NMTData nmtData)
    {
        this.nmtData = nmtData;
    }
    
    
    /**
     * method runs in resend thread
     */
    @Override
    public void run() {
    	System.out.println("ReSend Thread started");
        while(true)
        {
            try{
                Thread.sleep(CommunicationNetworkService.TIMEOUT_PERIOD);
            }
            catch(Exception e)
            {
                System.out.println("Error in resend thread run method.");
                break;
            }
            nmtData.resendData();
        }
        System.out.println("ReSend Thread Stopped");
    }
    
}


package edu.neu.d2.communication;


import java.util.Iterator;





import edu.neu.E.DataGenerate.EInterface;
import edu.neu.d1.communication.CommunicationInterface;
import edu.neu.d1.data.CommObj;

import edu.neu.d2.bean.D2CommObj;
import edu.neu.d2.communication.commService.CommunicationNetworkService;
import edu.neu.d2.information.InformationNetworkNode;
import edu.neu.d2.social.SocialNetworkNode;
import edu.neu.d2.util.DBUtil;
import edu.neu.d2.util.NMTSimulatorService;


/**
 *
 * @author Salim
 * CommunicationNetworkNode Class implement CommunicationInterface
 * when we create new instance it create entire NMT and UI
 */
public class CommunicationNetworkNode implements CommunicationInterface{
    
    /**
     * unique Id of NMT
     */
	private final int nodeId;
    /**
     * Encapsulate all CommObj queue in one class for simplicity
     * and UI display  
     */
	private NMTData nmtData;
    /**
     * InformationNetworkNode
     */
	public InformationNetworkNode infoNetworkNode;
    /**
     * SocialNetworkNode
     */
	public SocialNetworkNode socialNetworkNode;
    /**
     * E-Team Interface
     */
	public static EInterface EINTERFACE;
    
    /**
     * CommunicationNetworkService
     * added for simplicity to create and start thread
     * whenever we create CommunicationNetworkNode
     */
	private CommunicationNetworkService communicationNetworkService;
    
    /**
     * 
     * @param nodeId
     * @param eInterface
     * Constructor
     */
	public CommunicationNetworkNode(int nodeId, EInterface eInterface)
    {
        this.nodeId = nodeId;
        this.nmtData = new NMTData();
        this.infoNetworkNode = new InformationNetworkNode();
        this.socialNetworkNode = new SocialNetworkNode();
        this.EINTERFACE = eInterface;
        NMTSimulatorService.nmtList.add(this);
        NMTSimulatorService.createJFrame(this);
        
        this.communicationNetworkService = new CommunicationNetworkService(this);
        
        //create database and schema
        DBUtil.createNMT(nodeId);
    }
    
    /**
     * 
     * @param commObj
     * @throws IllegalArgumentException
     * validate commObj
     */
	public void validateCommObj(CommObj commObj) throws IllegalArgumentException
    {
        System.out.println("validating CommObj :"+commObj.getMsgID());
    	String errorMssg = isValidateCommObj(commObj);
        if(errorMssg.length()>0)
            throw new IllegalArgumentException(errorMssg);
    }
    
    /**
     * Divide validateCommObj method just for simplicity
     * @param commObj
     * @return
     *
     */
	private static String isValidateCommObj(CommObj commObj)
    {
        StringBuilder errorMssg = new StringBuilder();
        if(commObj.getPriority()>10 || commObj.getPriority()<1)
            errorMssg.append("Invalid priority: "+commObj.getPriority()+"\n");
        if(commObj.getTargetNode()== 0)
            errorMssg.append("Invalid targetNode: "+commObj.getTargetNode()+"\n");
        if(commObj.getSrcNode()==0)
            errorMssg.append("Invalid source node: "+commObj.getSrcNode()+"\n");
        if(!isValidateResponseType(commObj.getNodeType()))
            errorMssg.append("Invalid responseType field: "+commObj.getNodeType()+"\n");
        
        return errorMssg.toString();
    }
    
    /**
     * Divide validate CommObj method for simplicity
     * @param nodeType
     * @return
     */
	private static boolean isValidateResponseType(int nodeType)
    {
        if(nodeType != 0 && nodeType!=1 && nodeType!=2)
            return false;
        return true;
    }

    /**
     * getter method for NMT data
     * @return
     */
	public NMTData getNmtData() {
        return nmtData;
    }

    /**
     * getter method for NMT ID
     * @return
     */
	public int getNodeId() {
        return nodeId;
    }
    
    /**
     * resend data
     */
	public void resendData()
    {
        this.nmtData.resendData();
    }
    
    /**
     * send data
     * @param commObj
     */
	public void sendData(D2CommObj commObj)
    {
        validateCommObj(commObj);
        nmtData.putIntoMessgQueue(commObj);
    }
    
    /**
     * send Acknowledgement
     * @param commObj
     */
	public void sendAck(CommObj commObj)
    {
        CommObj ack = D2CommObj.createAck(commObj, this.nodeId);
        sendData(D2CommObj.newD2CommObj(ack));
    }
    
    /**
     * delete CommObj from message bucket queue
     * when Ack received
     * @param commObj
     */
	public void deleteFromMessgBucket(CommObj commObj)
    {
        Iterator it =  nmtData.getMessageBuket().iterator();
        while(it.hasNext())
        {
            D2CommObj c = (D2CommObj)it.next();
            if(c.getMsgID()== commObj.getMsgID())
            {
               if(commObj.getNodeType()==0)
                socialNetworkNode.insertSentData(c); 
               else 
                infoNetworkNode.insertSentData(c);
                
                it.remove();
                break;
            }
        }
        //for UI display purpose
        this.nmtData.deleteFromPendingJTable(commObj);
    }
    
    @Override
    public void receiveData(edu.neu.d1.data.CommObj commObj)
    {
    	System.out.println("received commObj from E team interface: "+commObj.getMsgID());
        validateCommObj(commObj);
        //CommObj for send from E team
        if(commObj.getSrcNode()==this.nodeId && commObj.getAck()!=null && commObj.getAck()==false)
        {
        	sendData(D2CommObj.newD2CommObj(commObj));
        	return;
        }
        
        commObj.setTimeRec(System.currentTimeMillis());
        if(commObj.getAck()!=null && commObj.getAck()==true)
        {
            this.deleteFromMessgBucket(commObj);
            System.out.println("received Ack :"+commObj.getMsgID());
            this.getNmtData().deleteFromPendingJTable(commObj);
        }
        else{
                D2CommObj d2CommObj= D2CommObj.newD2CommObj(commObj);
                if(d2CommObj.getNodeType()==0)
                {
                    this.socialNetworkNode.insertData(d2CommObj);
                    System.out.println("moved to social node: "+commObj.getMsgID());
                }
                else
                {
                    this.infoNetworkNode.insertData(d2CommObj);
                    System.out.println("moved to info node: "+commObj.getMsgID());
                }
                this.sendAck(commObj);
        }
        
    }

}

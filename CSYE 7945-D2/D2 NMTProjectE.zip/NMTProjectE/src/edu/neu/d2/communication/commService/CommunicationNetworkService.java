
package edu.neu.d2.communication.commService;


import edu.neu.d2.communication.CommunicationNetworkNode;



/**
 *
 * @author Salim
 * Class added for creating threads
 */
public class CommunicationNetworkService {
    
    /**
     * Send Thread
     */
	private Thread sendThread;
    
	/**
	 * Resend Thread
	 */
	private Thread resendThread;
    
    public static volatile long TIMEOUT_PERIOD = 5*1000;
    private CommunicationNetworkNode communicationNetworkNode;
    
    /**
     * 
     * @param communicationNetworkNode
     * Constructor calls new new CommunicationNetworkNode created
     */
    public CommunicationNetworkService(CommunicationNetworkNode communicationNetworkNode)
    {
        this.communicationNetworkNode = communicationNetworkNode;
    	startThreads();
    }
    
    /**
     * create thread and start
     */
    public void startThreads()
    {
        SendDataThread sdt = new SendDataThread(communicationNetworkNode.getNmtData());
        ResendDataThread rsdt = new ResendDataThread(communicationNetworkNode.getNmtData());
        
        sendThread = new Thread(sdt);
        resendThread = new Thread(rsdt);
        
        sendThread.start();
        resendThread.start();
    }
    
//    public int getId()
//    {
//        return this.communicationNetworkNode.getNodeId();
//    }
    
}

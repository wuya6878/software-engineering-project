
package edu.neu.d2.communication.commService;

import edu.neu.d2.bean.D2CommObj;
import edu.neu.d2.communication.CommunicationNetworkNode;
import edu.neu.d2.communication.NMTData;
/**
 *
 * @author Salim
 * Send Thread Class
 */
public class SendDataThread implements Runnable{
    
    private NMTData nmtData;
    
    /**
     * 
     * @param nmtData
     * constructor
     */
    public SendDataThread(NMTData nmtData)
    {
        this.nmtData = nmtData;
    }

    /**
     * run thread method for send Thread
     */
    @Override
    public void run() {
    	System.out.println("Send Thread started");
        while(true)
        {
            try{
                D2CommObj d2CommObj = nmtData.pullMssgCommObj();
                d2CommObj.setTimeSent(System.currentTimeMillis());
                System.out.println("sending : "+(d2CommObj.getAck()!=null && d2CommObj.getAck()==true?"Ack":"data")+" : "+d2CommObj.getMsgID());
                if(d2CommObj.getAck()!=null && d2CommObj.getAck()==true)
                {
                    System.out.println("sent Ack : "+d2CommObj.getMsgID());
                }
                else
                {
                    System.out.println("putting into bucket queue :"+d2CommObj.getMsgID());
                    this.nmtData.putIntoMessgBucket(d2CommObj);
                    //System.out.println("sent data : "+d2CommObj.getMsgID());
                }
                
                System.out.println("calling E team interface to send "+(d2CommObj.getAck()!=null && d2CommObj.getAck()==true?"Ack":"data")+" : "+d2CommObj.getMsgID());
                CommunicationNetworkNode.EINTERFACE.ReceiveData(D2CommObj.ToCommObj(d2CommObj));
            }
            catch(Exception e)
            {
                e.printStackTrace();
                break;
            }
        }
        
        System.out.println("Send Thread Stopped");
    }
    
}

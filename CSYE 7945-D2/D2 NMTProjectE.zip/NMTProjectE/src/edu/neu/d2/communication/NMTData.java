/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.d2.communication;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import edu.neu.d1.data.CommObj;
import edu.neu.d2.ui.NMTCommunicationJPanel;

import edu.neu.d2.bean.D2CommObj;

/**
 *Encapsulate NMT data into one class
 *for simplicity for UI
 * @author Salim
 */
public class NMTData {
    
    /**
     * PriorityBlockingQueue
     * Contains all CommObj to be sent
     */
	private PriorityBlockingQueue<D2CommObj> messageQueue;
   
	/**
	 * CommObj queue
	 * Contains all CommObj for which
	 * NMT didn't recieve Ack.
	 */
	private LinkedBlockingQueue<D2CommObj> messageBuket;
    
    /**
     * added for UI purpose
     */
    private NMTCommunicationJPanel jPanel;
    DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss.SSS");
    Calendar calendar = Calendar.getInstance();
    
    /**
     * constructor
     */
    public NMTData()
    {
        this.messageQueue = new PriorityBlockingQueue<D2CommObj>();
        this.messageBuket = new LinkedBlockingQueue<D2CommObj>();
    }

    /**
     * getter method for commObj queue
     * @return
     */
    public LinkedBlockingQueue<D2CommObj> getMessageBuket() {
        return messageBuket;
    }

    /**
     * gette method for Messg Queue
     * @return
     */
    public PriorityBlockingQueue<D2CommObj> getMessageQueue() {
        return messageQueue;
    }
    
    /**
     * put commObj into priority queue for send
     * and notify send thread
     * @param commObj
     */
    public synchronized void putIntoMessgQueue(D2CommObj commObj)
    {
        messageQueue.put(commObj);
        notifyAll();
    }
    
    /**
     * pull commObj from messg queue by send thread
     * @return
     * @throws InterruptedException
     */
    public synchronized D2CommObj pullMssgCommObj() throws InterruptedException
    {
        while(messageQueue.isEmpty())
            wait();
        return messageQueue.poll();
    }
    
    /**
     * put into message bucket queue for backup
     * @param commObj
     */
    public void putIntoMessgBucket(D2CommObj commObj)
    {
        messageBuket.add(commObj);
        //added for diplay purpose
        //if(!commObj.getAck())
        if(commObj.getAck()==null || commObj.getAck()==false)
            addIntoPendingJTable(commObj);
    }
    

    /**
     * resend data
     */
    public void resendData()
    {
        if(!messageBuket.isEmpty())
        {
            System.out.println("Trying to resend...");
            D2CommObj resendCommObj = messageBuket.poll();
            putIntoMessgQueue(resendCommObj);
            //for UI diaplay purpose
            deleteFromPendingJTable(resendCommObj);
        }
    }
    
    /**
     * added for UI purpose
     * @param jPanel
     */
    public void setCommHistoryJPanle(NMTCommunicationJPanel jPanel)
    {
        this.jPanel = jPanel;
    }
    
    /**
     * added for UI purpose
     * @param commObj
     */
    public void addIntoPendingJTable(CommObj commObj)
    {
         Object[] row = new Object[6];
         row[0] = commObj.getMsgID();
         row[1] = commObj.getSrcNode();
         row[2] = commObj.getTargetNode();
         row[3]= commObj.getNodeType()==0?"Social" : "Information";
         row[4] = commObj.getPriority();
         calendar.setTimeInMillis(commObj.getTimeSent());
         row[5] = formatter.format(calendar.getTime());
         ((DefaultTableModel) this.jPanel.pendingJTable.getModel()).addRow(row);
    }
    
    /**
     * added for UI purpose
     * @param commObj
     */
    public void deleteFromPendingJTable(CommObj commObj)
    {
        int rowCount = this.jPanel.pendingJTable.getRowCount();
        int i;
        TableModel model = null;
        for (i = rowCount - 1; i >= 0; i--) 
        {
            model = this.jPanel.pendingJTable.getModel();
            if((Integer)model.getValueAt(i, 0)== commObj.getMsgID())
                    //&&(Integer)model.getValueAt(i, 1)==commObj.getSrcNode())
            {
                ((DefaultTableModel) this.jPanel.pendingJTable.getModel()).removeRow(i);
                break;
            }
        }
    }
    
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * MainJFrame.java
 *
 * Created on Mar 29, 2010, 7:36:18 PM
 */

package edu.neu.d2.ui;



import java.util.Random;


import edu.neu.d1.data.CommObj;
import edu.neu.d2.bean.D2CommObj;
import edu.neu.d2.communication.CommunicationNetworkNode;
import edu.neu.d2.util.NMTSimulatorService;

/**
 *
 * @author salim
 */
public class NMTJFrame extends javax.swing.JFrame {

private final int nodeId;
private Random random = new Random();
private CommunicationNetworkNode commService;
NMTCommunicationJPanel communicationJPanel;


    public NMTJFrame(int nodeId,CommunicationNetworkNode commService) {
        this.nodeId = nodeId;
        this.commService = commService;
        initComponents();
        populateJComBox();
        titleJLabel.setText(titleJLabel.getText()+nodeId);
        nmtCommHistoryJPan();
        //this.communicationJPanel.populateCommHistoryTable(commService);
        commService.socialNetworkNode.setJPanel(communicationJPanel);
        commService.infoNetworkNode.setJPanel(communicationJPanel);
        commService.getNmtData().setCommHistoryJPanle(communicationJPanel);
    }
    
public void populateJComBox()
{
    desNodeJCombo.removeAllItems();
    for(CommunicationNetworkNode cns : NMTSimulatorService.nmtList)
    {
        if(cns.getNodeId()== this.nodeId)
            continue;
        desNodeJCombo.addItem(cns.getNodeId());
    }
}

 public void nmtCommHistoryJPan()
 {
        this.communicationJPanel = new NMTCommunicationJPanel();
        UserProcessContainerJPanl.removeAll();
        UserProcessContainerJPanl.add("commHistory",communicationJPanel);
        ((java.awt.CardLayout) UserProcessContainerJPanl.getLayout()).next(UserProcessContainerJPanl);
 }
 
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
 private void initComponents() {

     buttonGroup1 = new javax.swing.ButtonGroup();
     titleJLabel = new javax.swing.JLabel();
     jScrollPane1 = new javax.swing.JScrollPane();
     jSplitPane1 = new javax.swing.JSplitPane();
     jPanel1 = new javax.swing.JPanel();
     jLabel2 = new javax.swing.JLabel();
     jLabel6 = new javax.swing.JLabel();
     desNodeJCombo = new javax.swing.JComboBox();
     jLabel7 = new javax.swing.JLabel();
     nodeTypeJComboBox = new javax.swing.JComboBox();
     jLabel4 = new javax.swing.JLabel();
     priorityJComboBox = new javax.swing.JComboBox();
     jLabel5 = new javax.swing.JLabel();
     dataJTextField = new javax.swing.JTextField();
     createCommObjBttn = new javax.swing.JButton();
     jPanel2 = new javax.swing.JPanel();
     UserProcessContainerJPanl = new javax.swing.JPanel();
     jPanel3 = new javax.swing.JPanel();

     setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

     titleJLabel.setFont(new java.awt.Font("Tahoma", 1, 36));
     titleJLabel.setForeground(new java.awt.Color(153, 0, 0));
     titleJLabel.setText("NMT - ");

     jSplitPane1.setDividerLocation(200);

     jPanel1.setLayout(new edu.neu.d2.netbean_lib.awtextra.AbsoluteLayout());

     jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14));
     jLabel2.setText("Send Message:");
     jPanel1.add(jLabel2, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

     jLabel6.setText("Dest Node:");
     jPanel1.add(jLabel6, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(10, 50, -1, -1));

     jPanel1.add(desNodeJCombo, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(70, 50, 92, -1));

     jLabel7.setText("Data Type:");
     jPanel1.add(jLabel7, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

     nodeTypeJComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Social", "Information" }));
     jPanel1.add(nodeTypeJComboBox, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(70, 90, 94, -1));

     jLabel4.setText("Select Priority:");
     jPanel1.add(jLabel4, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));

     priorityJComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
     jPanel1.add(priorityJComboBox, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(90, 130, 45, -1));

     jLabel5.setText("Message:");
     jPanel1.add(jLabel5, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(10, 170, -1, -1));

     dataJTextField.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(java.awt.event.ActionEvent evt) {
             dataJTextFieldActionPerformed(evt);
         }
     });
     jPanel1.add(dataJTextField, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(60, 170, 96, -1));

     createCommObjBttn.setText("Send");
     createCommObjBttn.addActionListener(new java.awt.event.ActionListener() {
         public void actionPerformed(java.awt.event.ActionEvent evt) {
             createCommObjBttnActionPerformed(evt);
         }
     });
     jPanel1.add(createCommObjBttn, new edu.neu.d2.netbean_lib.awtextra.AbsoluteConstraints(60, 210, 100, -1));

     jSplitPane1.setLeftComponent(jPanel1);

     jPanel2.setLayout(new java.awt.BorderLayout());

     UserProcessContainerJPanl.setLayout(new java.awt.CardLayout());

     jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

     javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
     jPanel3.setLayout(jPanel3Layout);
     jPanel3Layout.setHorizontalGroup(
         jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGap(0, 638, Short.MAX_VALUE)
     );
     jPanel3Layout.setVerticalGroup(
         jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGap(0, 450, Short.MAX_VALUE)
     );

     UserProcessContainerJPanl.add(jPanel3, "card2");

     jPanel2.add(UserProcessContainerJPanl, java.awt.BorderLayout.CENTER);

     jSplitPane1.setRightComponent(jPanel2);

     jScrollPane1.setViewportView(jSplitPane1);

     javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
     getContentPane().setLayout(layout);
     layout.setHorizontalGroup(
         layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(layout.createSequentialGroup()
             .addContainerGap(399, Short.MAX_VALUE)
             .addComponent(titleJLabel)
             .addContainerGap(294, Short.MAX_VALUE))
         .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 813, Short.MAX_VALUE)
     );
     layout.setVerticalGroup(
         layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
         .addGroup(layout.createSequentialGroup()
             .addContainerGap()
             .addComponent(titleJLabel)
             .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
             .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 456, Short.MAX_VALUE))
     );

     pack();
 }// </editor-fold>//GEN-END:initComponents

private void infoNodeBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_infoNodeBttnActionPerformed
//        SocialAndInfoNodesJPanel sainJPanel = new SocialAndInfoNodesJPanel();
//        UserProcessContainerJPanl.removeAll();
//        UserProcessContainerJPanl.add("socialInfoNodeJPanel",sainJPanel);
//        ((java.awt.CardLayout) UserProcessContainerJPanl.getLayout()).next(UserProcessContainerJPanl);
}//GEN-LAST:event_infoNodeBttnActionPerformed

private void createCommObjBttnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createCommObjBttnActionPerformed

    int messgId = random.nextInt(1000);
    int priority = Integer.parseInt((String)priorityJComboBox.getSelectedItem());
    int desNode = (Integer)desNodeJCombo.getSelectedItem();
    int nodeType = ((String)nodeTypeJComboBox.getSelectedItem()).equalsIgnoreCase("Social")? 0 : 1;
    String data = dataJTextField.getText()!= null ? dataJTextField.getText():"";
    
    CommObj commObj = new CommObj();
    commObj.setSrcNode(this.nodeId);
    commObj.setTargetNode(desNode);
    commObj.setMsgID(messgId);
    commObj.setNodeType(nodeType);
    commObj.setPriority(priority);
    commObj.setData(data);
    commObj.setFieldType("Message");
    
    commService.sendData(D2CommObj.newD2CommObj(commObj));
        
}//GEN-LAST:event_createCommObjBttnActionPerformed

private void dataJTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dataJTextFieldActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_dataJTextFieldActionPerformed

    public static NMTJFrame createNMTNode(CommunicationNetworkNode commService) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NMTJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NMTJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NMTJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NMTJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
               NMTJFrame jframe=  new NMTJFrame(commService.getNodeId(),commService);
               jframe.setVisible(true);
               return jframe;    
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel UserProcessContainerJPanl;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton createCommObjBttn;
    private javax.swing.JTextField dataJTextField;
    private javax.swing.JComboBox desNodeJCombo;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JComboBox nodeTypeJComboBox;
    private javax.swing.JComboBox priorityJComboBox;
    private javax.swing.JLabel titleJLabel;
    // End of variables declaration//GEN-END:variables

}

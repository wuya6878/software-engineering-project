package edu.neu.d2.bean;

import edu.neu.d1.data.CommObj;



/**
 *
 * @author Salim
 */
public class D2CommObj extends CommObj implements Comparable<CommObj>{
    

    public CommObj clone(CommObj commObj)
    {
        return new CommObj();
    }
    
        @Override
        public int compareTo(CommObj obj) {
        final int BEFORE = -1;
        final int EQUAL = 0;
        final int AFTER = 1;
        
        if(this.getPriority() == obj.getPriority())
            return EQUAL;
       if (this.getPriority() < obj.getPriority()) 
           return BEFORE;
       else 
           return AFTER;
    }
    
        public static D2CommObj newD2CommObj(CommObj commObj)
        {
            D2CommObj d2CommObj = new D2CommObj();
            d2CommObj.setAck(commObj.getAck());
            d2CommObj.setData(commObj.getData());
            d2CommObj.setFieldType(commObj.getFieldType());
            d2CommObj.setMsgID(commObj.getMsgID());
            d2CommObj.setNodeType(commObj.getNodeType());
            d2CommObj.setPriority(commObj.getPriority());
            d2CommObj.setSrcNode(commObj.getSrcNode());
            d2CommObj.setTargetNode(commObj.getTargetNode());
            d2CommObj.setTimeRec(commObj.getTimeRec());
            d2CommObj.setTimeSent(commObj.getTimeSent());
            
            return d2CommObj;
        }
        
        public static D2CommObj createAck(CommObj commObj, int srcNodeId)
        {
            D2CommObj ack = new D2CommObj();
            ack.setAck(true);
            ack.setData(commObj.getData());
            ack.setFieldType(commObj.getFieldType());
            ack.setMsgID(commObj.getMsgID());
            ack.setNodeType(commObj.getNodeType());
            ack.setPriority(commObj.getPriority());
            ack.setTimeRec(commObj.getTimeRec());
            ack.setTimeSent(commObj.getTimeSent());

            int targetNode = commObj.getSrcNode();
            ack.setSrcNode(srcNodeId);
            ack.setTargetNode(targetNode);
            
            return ack;
        }
        
        public static CommObj ToCommObj(D2CommObj d2CommObj)
        {
            CommObj commObj = new CommObj();
            commObj.setAck(d2CommObj.getAck());
            commObj.setData(d2CommObj.getData());
            commObj.setFieldType(d2CommObj.getFieldType());
            commObj.setMsgID(d2CommObj.getMsgID());
            commObj.setNodeType(d2CommObj.getNodeType());
            commObj.setPriority(d2CommObj.getPriority());
            commObj.setSrcNode(d2CommObj.getSrcNode());
            commObj.setTargetNode(d2CommObj.getTargetNode());
            commObj.setTimeRec(d2CommObj.getTimeRec());
            commObj.setTimeSent(d2CommObj.getTimeSent());
            
            return commObj;
        }
}

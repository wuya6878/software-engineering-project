package edu.neu.d2.util;


import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import edu.neu.d1.data.CommObj;

/**
 *Class for DB util
 * @author TR
 */
public class DBUtil {

    /**
     * Data base URI
     */
	private static final String URL = "jdbc:mysql://localhost:3306/";
    /**
     * DB Username
     */
	private static final String USERNAME = "root";
    /**
     * DB password
     */
	private static final String PWD = "";
    /**
     * DB name
     */
	private static final String DB_NAME = "NMT";
    /**
     * DB Connection Obj
     */
	private static Connection connection;

    /**
     * create and get DB connection
     * @return
     */
	public static Connection getDBConnection() {
        if (connection == null) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                //create database if not exist
                connection = DriverManager.getConnection(URL, USERNAME, PWD);
                String createDB = "CREATE DATABASE IF NOT EXISTS "+DB_NAME;
                Statement s = connection.createStatement();
                s.executeUpdate(createDB);
                connection.close();
                
                String url = "jdbc:mysql://localhost:3306/" + DB_NAME;
                connection = DriverManager.getConnection(url, USERNAME, PWD);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return connection;
    }

    /**
     * create NMT database schema if not exist
     * @param _NMTID
     */
	public static void createNMT(int _NMTID) {
        // String NMTID = "NMT_" + String.valueOf(_NMTID);
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();
            String _myUpdate = new String("DROP TABLE IF EXISTS `" + _NMTID + "`");
            String _myCreateTable = new String(
                    "CREATE  TABLE `NMT`.`" + _NMTID + "` ("
                    + "`MsgId` INT NOT NULL ,"
                    + "`TargetNode` INT NULL ,"
                    + "`SrcNode` INT NULL ,"
                    + "`NodeType` INT NULL ,"
                    + "`FieldType` VARCHAR(45) NULL ,"
                    + "`Data` VARCHAR(45) NULL ,"
                    + "`TimeSent` VARCHAR(45) NULL ,"
                    + "`TimeRec` VARCHAR(45) NULL ,"
                    + "`Priority` INT NULL ,"
                    + "`Ack` TINYINT(1) NULL ,"
                    + "PRIMARY KEY (`MsgId`) );");
            s.executeUpdate(_myUpdate);
            s.executeUpdate(_myCreateTable);
            s.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	/**
	 * insert into DB
	 * @param _COMMOBJ
	 * @param _NMTID
	 */
    public static void insertCommObj(CommObj _COMMOBJ, int _NMTID) {
        // String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();

            String _myInsert = new String(
                    "INSERT INTO `NMT`.`" + _NMTID + "` VALUES("
                    + String.valueOf(_COMMOBJ.getMsgID()) + ", "
                    + "'" + String.valueOf(_COMMOBJ.getTargetNode()) + "', "
                    + "'" + String.valueOf(_COMMOBJ.getSrcNode()) + "', "
                    + "'" + String.valueOf(_COMMOBJ.getNodeType()) + "', "
                    + "'" + String.valueOf(_COMMOBJ.getFieldType()) + "', "
                    + "'" + _COMMOBJ.getData().toString() + "', " //Need to specific the attributes of 'Data' 
                    + "'" + String.valueOf(_COMMOBJ.getTimeSent()) + "', "
                    + "'" + String.valueOf(_COMMOBJ.getTimeRec()) + "', "
                    + String.valueOf(_COMMOBJ.getPriority()) + ","
                    + String.valueOf(_COMMOBJ.getAck()!=null && _COMMOBJ.getAck()==true?"true":"false")+");");
            int count;
            System.out.println(_myInsert);//test_output
            count = s.executeUpdate(_myInsert);
            s.close();
            
            System.out.println(count + " rows were inserted");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * update DB
     * @param _COMMOBJ
     * @param _targetObj
     * @param _NMTID
     */
    public static void updateCommObj(CommObj _COMMOBJ, CommObj _targetObj, int _NMTID) {
        //String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();

            String _myUpdate = new String(
                    "UPDATE `NMT`.`" + _NMTID + " `SET "
                    + "MsgId = " + String.valueOf(_COMMOBJ.getMsgID()) + ", "
                    + "TargetNode = 'NMT_" + String.valueOf(_COMMOBJ.getTargetNode()) + "', "
                    + "SrcNode = 'NMT_" + String.valueOf(_COMMOBJ.getSrcNode()) + "', "
                    + "NodeType = '" + String.valueOf(_COMMOBJ.getNodeType()) + "', "
                    + "FieldType = '" + _COMMOBJ.getFieldType() + "', "
                    + "Data = '" + _COMMOBJ.getData().toString() + "', " //Need to specific the attributes of 'Data' 
                    + "TimeSent = '" + String.valueOf(_COMMOBJ.getTimeSent()) + "', "
                    + "TimeRec = '" + String.valueOf(_COMMOBJ.getTimeRec()) + "', "
                    + "Priority = '" + _COMMOBJ.getPriority() + "' "
                    + "WHERE `NMT`.`" + _NMTID + "`.`MsgId = " + _targetObj.getMsgID() + ");");
            int count;
            System.out.println(_myUpdate);//test_output
            count = s.executeUpdate(_myUpdate);
            s.close();
            System.out.println(count + " rows were UPDATED");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

 /**
  * delete from DB
  * @param _COMMOBJ
  * @param _NMTID
  */
    public static void deleteCommObj(CommObj _COMMOBJ, int _NMTID) {
        //String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();

            String _myDeletE = new String(
                    "DELETE FROM NMT.`" + _NMTID
                    + "` WHERE MsgId = " + _COMMOBJ.getMsgID() + ";");
            int count;
            System.out.println(_myDeletE);//test_output
            count = s.executeUpdate(_myDeletE);
            s.close();
            System.out.println(count + " rows were DELETED");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * select from DB
     * @param _MsgId
     * @param _NMTID
     * @return
     */
    public static ArrayList<CommObj> selectCommObj(int _MsgId, int _NMTID) {
        //String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        ArrayList<CommObj> CommObjList = new ArrayList();
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();
            ResultSet _rs;
            String _myQuery = new String(
                    "SELECT * FROM `" + _NMTID
                    + "` WHERE MsgId = " + _MsgId + ";");
            System.out.println(_myQuery);//test_output
            _rs = s.executeQuery(_myQuery);
            while (_rs.next()) {
                Object _Data = new Object();        //************ Data? Object? Cannot be String?
                int MsgId = _rs.getInt("MsgId");
                int NodeType = _rs.getInt("NodeType");    //******** What`s responseType? Same as Node Type?
                String FieldType = _rs.getString("FieldType");
                int SrcNode = _rs.getInt("SrcNode");
                int TargetNode = _rs.getInt("TargetNode");
                Long TimeSent = _rs.getLong("TimeSent");
                Long TimeRec = _rs.getLong("TimeRec");
                int Priority = _rs.getInt("Priority");
                CommObj _COMMOBJ = new CommObj();
                _COMMOBJ.setData(_Data);
                _COMMOBJ.setMsgID(MsgId);
                _COMMOBJ.setFieldType(FieldType);
                _COMMOBJ.setPriority(Priority);
                _COMMOBJ.setSrcNode(SrcNode);
                _COMMOBJ.setTargetNode(TargetNode);
                _COMMOBJ.setTimeRec(TimeRec);
                _COMMOBJ.setTimeSent(TimeSent);
                _COMMOBJ.setNodeType(NodeType);
                CommObjList.add(_COMMOBJ);
            }
            s.close();
            return CommObjList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

   /**
    * select from DB
    * @param _NMTID
    * @return
    */
    public static ArrayList<CommObj> selectCommObj(int _NMTID) {
        //String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        ArrayList<CommObj> CommObjList = new ArrayList();
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();
            ResultSet _rs;
            String _myQuery = new String(
                    "SELECT * FROM `" + _NMTID +"`;");
            System.out.println(_myQuery);//test_output
            _rs = s.executeQuery(_myQuery); 
            while (_rs.next()) {
                Object _Data = new Object();        //************ Data? Object? Cannot be String?
                int MsgId = _rs.getInt("MsgId");
                int NodeType = _rs.getInt("NodeType");    //******** What`s responseType? Same as Node Type?
                String FieldType = _rs.getString("FieldType");
                int SrcNode = _rs.getInt("SrcNode");
                int TargetNode = _rs.getInt("TargetNode");
                Long TimeSent = _rs.getLong("TimeSent");
                Long TimeRec = _rs.getLong("TimeRec");
                int Priority = _rs.getInt("Priority");
                CommObj _COMMOBJ = new CommObj();
                _COMMOBJ.setData(_Data);
                _COMMOBJ.setMsgID(MsgId);
                _COMMOBJ.setFieldType(FieldType);
                _COMMOBJ.setPriority(Priority);
                _COMMOBJ.setSrcNode(SrcNode);
                _COMMOBJ.setTargetNode(TargetNode);
                _COMMOBJ.setTimeRec(TimeRec);
                _COMMOBJ.setTimeSent(TimeSent);
                _COMMOBJ.setNodeType(NodeType);
                CommObjList.add(_COMMOBJ);
                String lastName = _rs.getString("MsgId"); // testing
                System.out.println(lastName); // testing
            }
            s.close();
            return CommObjList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * select from DB
     * @param _NMTID
     * @return
     */
    public static ArrayList<CommObj> selectSentCommObj(int _NMTID) {
        //String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        ArrayList<CommObj> CommObjList = new ArrayList();
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();
            ResultSet _rs;
            String _myQuery = new String(
                    "SELECT * FROM `" + _NMTID +"` WHERE SrcNode = " + _NMTID + ";");
            System.out.println(_myQuery);//test_output
            _rs = s.executeQuery(_myQuery); 
            while (_rs.next()) {
                Object _Data = new Object();        //************ Data? Object? Cannot be String?
                int MsgId = _rs.getInt("MsgId");
                int NodeType = _rs.getInt("NodeType");    //******** What`s responseType? Same as Node Type?
                String FieldType = _rs.getString("FieldType");
                int SrcNode = _rs.getInt("SrcNode");
                int TargetNode = _rs.getInt("TargetNode");
                Long TimeSent = _rs.getLong("TimeSent");
                Long TimeRec = _rs.getLong("TimeRec");
                int Priority = _rs.getInt("Priority");
                CommObj _COMMOBJ = new CommObj();
                _COMMOBJ.setData(_Data);
                _COMMOBJ.setMsgID(MsgId);
                _COMMOBJ.setFieldType(FieldType);
                _COMMOBJ.setPriority(Priority);
                _COMMOBJ.setSrcNode(SrcNode);
                _COMMOBJ.setTargetNode(TargetNode);
                _COMMOBJ.setTimeRec(TimeRec);
                _COMMOBJ.setTimeSent(TimeSent);
                _COMMOBJ.setNodeType(NodeType);
                CommObjList.add(_COMMOBJ);
                String lastName = _rs.getString("MsgId"); // testing
                System.out.println(lastName); // testing
            }
            s.close();
            return CommObjList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

/**
 * select from recieved DB
 * @param _NMTID
 * @return
 */
    public static ArrayList<CommObj> selectRecievedCommObj(int _NMTID) {
        //String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        ArrayList<CommObj> CommObjList = new ArrayList();
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();
            ResultSet _rs;
            String _myQuery = new String(
                    "SELECT * FROM `" + _NMTID +"` WHERE TargetNode = " + _NMTID + ";");
            System.out.println(_myQuery);//test_output
            _rs = s.executeQuery(_myQuery); 
            while (_rs.next()) {
                Object _Data = new Object();        //************ Data? Object? Cannot be String?
                int MsgId = _rs.getInt("MsgId");
                int NodeType = _rs.getInt("NodeType");    //******** What`s responseType? Same as Node Type?
                String FieldType = _rs.getString("FieldType");
                int SrcNode = _rs.getInt("SrcNode");
                int TargetNode = _rs.getInt("TargetNode");
                Long TimeSent = _rs.getLong("TimeSent");
                Long TimeRec = _rs.getLong("TimeRec");
                int Priority = _rs.getInt("Priority");
                CommObj _COMMOBJ = new CommObj();
                _COMMOBJ.setData(_Data);
                _COMMOBJ.setMsgID(MsgId);
                _COMMOBJ.setFieldType(FieldType);
                _COMMOBJ.setPriority(Priority);
                _COMMOBJ.setSrcNode(SrcNode);
                _COMMOBJ.setTargetNode(TargetNode);
                _COMMOBJ.setTimeRec(TimeRec);
                _COMMOBJ.setTimeSent(TimeSent);
                _COMMOBJ.setNodeType(NodeType);
                CommObjList.add(_COMMOBJ);
                String lastName = _rs.getString("MsgId"); // testing
                System.out.println(lastName); // testing
            }
            s.close();
            return CommObjList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

/**
 * select ready to send CommObj
 * @param _NMTID
 * @return
 */
    public static ArrayList<CommObj> selectReadyToSendCommObj(int _NMTID) {
        //String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        ArrayList<CommObj> CommObjList = new ArrayList();
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();
            ResultSet _rs;
            String _myQuery = new String(
                    "SELECT * FROM `" + _NMTID +"` WHERE Ack = 0 AND SroNode !=" + _NMTID + ";");
            System.out.println(_myQuery);//test_output
            _rs = s.executeQuery(_myQuery); 
            while (_rs.next()) {
                Object _Data = new Object();        //************ Data? Object? Cannot be String?
                int MsgId = _rs.getInt("MsgId");
                int NodeType = _rs.getInt("NodeType");    //******** What`s responseType? Same as Node Type?
                String FieldType = _rs.getString("FieldType");
                int SrcNode = _rs.getInt("SrcNode");
                int TargetNode = _rs.getInt("TargetNode");
                Long TimeSent = _rs.getLong("TimeSent");
                Long TimeRec = _rs.getLong("TimeRec");
                int Priority = _rs.getInt("Priority");
                CommObj _COMMOBJ = new CommObj();
                _COMMOBJ.setData(_Data);
                _COMMOBJ.setMsgID(MsgId);
                _COMMOBJ.setFieldType(FieldType);
                _COMMOBJ.setPriority(Priority);
                _COMMOBJ.setSrcNode(SrcNode);
                _COMMOBJ.setTargetNode(TargetNode);
                _COMMOBJ.setTimeRec(TimeRec);
                _COMMOBJ.setTimeSent(TimeSent);
                _COMMOBJ.setNodeType(NodeType);
                CommObjList.add(_COMMOBJ);
                String lastName = _rs.getString("MsgId"); // testing
                System.out.println(lastName); // testing
            }
            s.close();
            return CommObjList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

/**
 * select commObj for display
 * @param _NodeType
 * @param _NMTID
 * @return
 */
    public static ArrayList<CommObj> selectDesplayingCommObj(int _NodeType, int _NMTID) 
	{
        //String THIS_NMT = "NMT_" + String.valueOf(_NMTID);
        ArrayList<CommObj> CommObjList = new ArrayList();
        try {
            Connection conn = getDBConnection();
            Statement s = conn.createStatement();
            ResultSet _rs;
            String _myQuery = new String(
                    "SELECT * FROM `" + _NMTID +"` WHERE NodeType="+ _NodeType + ";");
            System.out.println(_myQuery);//test_output
            _rs = s.executeQuery(_myQuery); 
            while (_rs.next()) {
                Object _Data = new Object();        //************ Data? Object? Cannot be String?
                int MsgId = _rs.getInt("MsgId");
                int NodeType = _rs.getInt("NodeType");    //******** What`s responseType? Same as Node Type?
                String FieldType = _rs.getString("FieldType");
                int SrcNode = _rs.getInt("SrcNode");
                int TargetNode = _rs.getInt("TargetNode");
                Long TimeSent = _rs.getLong("TimeSent");
                Long TimeRec = _rs.getLong("TimeRec");
                int Priority = _rs.getInt("Priority");
                CommObj _COMMOBJ = new CommObj();
                _COMMOBJ.setData(_Data);
                _COMMOBJ.setMsgID(MsgId);
                _COMMOBJ.setFieldType(FieldType);
                _COMMOBJ.setPriority(Priority);
                _COMMOBJ.setSrcNode(SrcNode);
                _COMMOBJ.setTargetNode(TargetNode);
                _COMMOBJ.setTimeRec(TimeRec);
                _COMMOBJ.setTimeSent(TimeSent);
                _COMMOBJ.setNodeType(NodeType);
                CommObjList.add(_COMMOBJ);
                String lastName = _rs.getString("MsgId"); // testing
                System.out.println(lastName); // testing
            }
            s.close();
            return CommObjList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }







}
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.d2.util;


import java.util.ArrayList;
import java.util.List;

import edu.neu.d2.communication.CommunicationNetworkNode;
import edu.neu.d2.ui.NMTJFrame;



/**
 *Class added for UI
 * @author Salim
 */
public class NMTSimulatorService {
    
    /**
     * added for UI
     */
	public static List<CommunicationNetworkNode> nmtList = new ArrayList<CommunicationNetworkNode>();
    /**
     * added for UI
     */
	public static List<Integer> deactiveNodeList = new ArrayList<Integer>();
    /**
     * added for UI
     */
	public static List<NMTJFrame> NMTJFarmeList = new ArrayList<NMTJFrame>();
    
    /**
     * create new JFrame
     * @param commService
     */
	public static void createJFrame(CommunicationNetworkNode commService)
    {
	    NMTJFarmeList.add(NMTJFrame.createNMTNode(commService));
	   for(NMTJFrame jframe : NMTJFarmeList)
	   {
	       jframe.populateJComBox();
	   }
    }
    
}

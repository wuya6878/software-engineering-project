/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.neu.d2.information;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.swing.table.DefaultTableModel;



import edu.neu.d1.data.CommObj;
import edu.neu.d2.bean.D2CommObj;
import edu.neu.d2.ui.NMTCommunicationJPanel;
import edu.neu.d2.util.DBUtil;



/**
 *InformationNetworkNode class
 * @author Salim
 */
public class InformationNetworkNode {
    
    /**
     * received CommObj list added for UI
     */
	private List<CommObj> recievedInfoDataList;
    /**
     * sent CommObj list added for UI
     */
	private List<CommObj> sentInfoDataList;
    
    /**
     * added for UI
     */
	private NMTCommunicationJPanel jPanel;
    DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss.SSS");
    Calendar calendar = Calendar.getInstance();
    
   /**
    * constructor 
    */
    public InformationNetworkNode()
    {
        this.recievedInfoDataList = new ArrayList<CommObj>();
        this.sentInfoDataList = new ArrayList<CommObj>();
    }

    /**
     * getter method for list (for UI)
     * @return
     */
    public List<CommObj> getRecievedInfoDataList() {
        return recievedInfoDataList;
    }

   /**
    * getter method for list (for UI)
    * @return
    */
    public List<CommObj> getSentInfoDataList() {
        return sentInfoDataList;
    }
    /**
     * insert all received data into list
     * and display it on UI
     * @param commObj
     */
    public void insertData(CommObj commObj)
    {
        this.recievedInfoDataList.add(commObj);
        addRecivedRowToJTable(commObj);
        
        addToInformationJTable(commObj);
        
        //new commObj for Db
        D2CommObj dbCommObj = D2CommObj.newD2CommObj(commObj);
        dbCommObj.setAck(true);
        DBUtil.insertCommObj(dbCommObj, dbCommObj.getTargetNode());
    }
    
    /**
     * insert all send data into list
     * and display it on UI
     * @param commObj
     */
    public void insertSentData(CommObj commObj)
    {
        this.sentInfoDataList.add(commObj);
        addSentRowToJTable(commObj);
    }
    
    /**
     * added for UI
     * @param jPanel
     */
    public void setJPanel(NMTCommunicationJPanel jPanel)
    {
        this.jPanel = jPanel;
    }
    
    /**
     * added for UI
     * @param commObj
     */
    public void addRecivedRowToJTable(CommObj commObj)
    {
        Object[] row = new Object[6];
         row[0] = commObj.getMsgID();
         row[1] = commObj.getSrcNode();
         row[2] = commObj.getTargetNode();
         row[3]=  commObj.getNodeType()==0?"Social" : "Information";
         row[4] = commObj.getPriority();
         calendar.setTimeInMillis(commObj.getTimeRec());
         row[5] = formatter.format(calendar.getTime());
         ((DefaultTableModel) this.jPanel.receivedPacketJTable.getModel()).addRow(row);
    }
    
    /**
     * added for UI
     * @param commObj
     */
    public void addSentRowToJTable(CommObj commObj)
    {
        Object[] row = new Object[6];
         row[0] = commObj.getMsgID();
         row[1] = commObj.getSrcNode();
         row[2] = commObj.getTargetNode();
         row[3]= commObj.getNodeType()==0?"Social" : "Information";
         row[4] = commObj.getPriority();
         calendar.setTimeInMillis(commObj.getTimeSent());
         row[5] = formatter.format(calendar.getTime());
         ((DefaultTableModel) this.jPanel.sentPacketsJTable.getModel()).addRow(row);
    }
    
    /**
     * added for UI
     * @param commObj
     */
    public void addToInformationJTable(CommObj commObj)
    {
         Object[] row = new Object[4];
         row[0] = commObj.getSrcNode();
         row[1] = commObj.getTargetNode();
         row[2] = commObj.getData().toString();
         calendar.setTimeInMillis(commObj.getTimeRec());
         row[3] = formatter.format(calendar.getTime());
         ((DefaultTableModel) this.jPanel.informationJTable.getModel()).addRow(row);
    }
    
}
